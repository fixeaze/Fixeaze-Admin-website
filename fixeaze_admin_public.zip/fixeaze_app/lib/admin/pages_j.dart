import 'package:flutter/material.dart';

import 'admin_store.dart';
import 'admin_util.dart';
import 'admin_widgets.dart';
import 'pages_a.dart';

AdminStore get _s => AdminStore.I;

Color _stColor(String st) => st == 'approved' ? kOk : (st == 'suspended' ? kBad : kWarn);

/// Hours worked on a booking: real start/finish if known, else booked hours.
num _hoursOf(Rec b) {
  final a = parseTime(b['started_at']);
  final f = parseTime(b['finished_at']);
  if (a != null && f != null && f.isAfter(a)) return f.difference(a).inMinutes / 60;
  return numOf(b['hours']);
}

// ============================================================== INSTITUTIONS

class InstitutionsPage extends StatefulWidget {
  const InstitutionsPage({super.key});
  @override
  State<InstitutionsPage> createState() => _InstitutionsPageState();
}

class _InstitutionsPageState extends State<InstitutionsPage> {
  @override
  void initState() {
    super.initState();
    _s.addListener(_changed);
  }

  void _changed() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _s.removeListener(_changed);
    super.dispose();
  }

  List<Rec> _employees(Rec inst) =>
      _s.profiles.where((p) => '${_s.TP['${p['id']}']?['institution_id']}' == '${inst['id']}').toList();

  Map<String, num> _stats(Rec inst) {
    final ids = _employees(inst).map((e) => '${e['id']}').toSet();
    final jobs = _s.bookings.where((b) => ids.contains('${b['technician_id']}') && b['status'] == 'completed').toList();
    final pays = _s.payments.where((p) => ids.contains('${p['technician_id']}')).toList();
    num sum(bool Function(Rec) t) => pays.where(t).fold<num>(0, (a, p) => a + numOf(p['amount']));
    return {
      'employees': ids.length,
      'jobs': jobs.length,
      'hours': jobs.fold<num>(0, (a, b) => a + _hoursOf(b)),
      'earned': sum((p) => true),
      'unpaid': sum((p) => p['status'] == 'pending' || p['status'] == 'processing'),
    };
  }

  @override
  Widget build(BuildContext context) {
    final s = _s;
    if (s.errors['institutions'] != null) {
      return ListView(padding: const EdgeInsets.all(16), children: [
        NoticeBanner('Institutions are not set up yet. Run sql/v2_part21_institutions.sql in Supabase. (${s.errors['institutions']})'),
      ]);
    }
    final list = s.institutions;
    final all = list.map(_stats).toList();
    num tot(String k) => all.fold<num>(0, (a, m) => a + (m[k] ?? 0));
    return ListView(padding: const EdgeInsets.all(16), children: [
      TileGrid([
        StatTile('Institutions', '${list.length}',
            sub: '${list.where((i) => i['status'] == 'pending').length} waiting for approval',
            alert: list.any((i) => i['status'] == 'pending')),
        StatTile('Employees', '${tot('employees')}'),
        StatTile('Hours worked', tot('hours').toStringAsFixed(1)),
        StatTile('Earned (net)', money(tot('earned')), sub: '${money(tot('unpaid'))} unpaid'),
      ]),
      const SectionTitle('All institutions'),
      AdminTable(
        columns: const ['Institution', 'Owner', 'Employees', 'Jobs', 'Hours', 'Earned', 'Unpaid', 'Status', ''],
        numeric: const {2, 3, 4, 5, 6},
        empty: 'No institutions have registered yet.',
        rows: [
          for (var i = 0; i < list.length; i++)
            [
              TwoLine('${list[i]['name']}', '${list[i]['address'] ?? ''}'),
              TwoLine(s.nameOf(list[i]['owner_id']), '${s.P['${list[i]['owner_id']}']?['phone'] ?? ''}'),
              Text('${all[i]['employees']}'),
              Text('${all[i]['jobs']}'),
              Text(all[i]['hours']!.toStringAsFixed(1)),
              Text(money(all[i]['earned'])),
              Text(money(all[i]['unpaid'])),
              Pill('${list[i]['status']}', _stColor('${list[i]['status']}')),
              Wrap(spacing: 6, children: [
                OutlinedButton(onPressed: () => _open(list[i]), child: const Text('Details')),
                if (list[i]['status'] != 'approved')
                  FilledButton(onPressed: () => _set(list[i], 'approved'), child: const Text('Approve')),
                if (list[i]['status'] == 'approved')
                  OutlinedButton(onPressed: () => _set(list[i], 'suspended'), child: const Text('Suspend')),
              ]),
            ],
        ],
      ),
    ]);
  }

  Future<void> _set(Rec inst, String st) async {
    if (st == 'suspended' &&
        !await confirmBox(context, 'Suspend ${inst['name']}? Its employees and owner will not be able to work.')) {
      return;
    }
    final err = await _s.institutionStatus('${inst['id']}', st);
    if (mounted) report(context, err, '${inst['name']} is now $st');
  }

  void _open(Rec inst) {
    final emps = _employees(inst);
    final ids = emps.map((e) => '${e['id']}').toSet();
    final jobs = _s.bookings.where((b) => ids.contains('${b['technician_id']}') && b['status'] == 'completed').toList();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('${inst['name']}'),
        content: SizedBox(
          width: 640,
          child: SingleChildScrollView(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Owner: ${_s.nameOf(inst['owner_id'])} · ${_s.P['${inst['owner_id']}']?['phone'] ?? ''}'),
              Text('GST: ${inst['gst'] ?? '-'}'),
              Text('Bank: ${inst['bank_holder_name'] ?? '-'} · ${inst['bank_name'] ?? '-'} · A/c ${inst['bank_account_no'] ?? '-'} · IFSC ${inst['bank_ifsc'] ?? '-'}'),
              Text('UPI: ${inst['upi_id'] ?? '-'}'),
              const SectionTitle('Employees'),
              AdminTable(
                columns: const ['Name', 'Phone', 'Jobs', 'Hours', 'Earned'],
                numeric: const {2, 3, 4},
                empty: 'No employees added yet.',
                rows: [
                  for (final e in emps)
                    () {
                      final id = '${e['id']}';
                      final j = jobs.where((b) => '${b['technician_id']}' == id).toList();
                      final earned = _s.payments
                          .where((p) => '${p['technician_id']}' == id)
                          .fold<num>(0, (a, p) => a + numOf(p['amount']));
                      return <Widget>[
                        Text('${e['name'] ?? ''}'),
                        Text('${e['phone'] ?? ''}'),
                        Text('${j.length}'),
                        Text(j.fold<num>(0, (a, b) => a + _hoursOf(b)).toStringAsFixed(1)),
                        Text(money(earned)),
                      ];
                    }(),
                ],
              ),
            ]),
          ),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
      ),
    );
  }
}
