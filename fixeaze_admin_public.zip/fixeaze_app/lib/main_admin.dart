import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'admin/admin_app.dart';
import 'config.dart';
import 'dark_mode.dart';
import 'services/native_push.dart';

/// Entry point of the separate Admin Dashboard site.
/// Build with:  flutter build web --release -t lib/main_admin.dart
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: AppConfig.supabaseUrl,
    anonKey: AppConfig.supabaseAnonKey,
  );
  await DarkMode.load();
  NativePush.start(admin: true); // phone notifications; does nothing on the website
  runApp(const AdminApp());
}
