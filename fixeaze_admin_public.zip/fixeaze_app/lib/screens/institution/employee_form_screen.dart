import 'dart:typed_data';

import 'package:flutter/material.dart';
import '../../dark_mode.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../config.dart';
import '../../services/pincode_service.dart';
import '../../services/validators.dart';
import '../../theme.dart';
import '../../widgets/common.dart';

typedef _Rec = Map<String, dynamic>;

/// Employee application filled in by the institution owner.
/// Same details and Aadhaar / selfie checks as an individual technician, but no bank account:
/// all payments go to the institution.
/// Pops with {name, email, password} when the employee was created.
class EmployeeFormScreen extends StatefulWidget {
  final String defaultPin;
  const EmployeeFormScreen({super.key, this.defaultPin = ''});

  @override
  State<EmployeeFormScreen> createState() => _EmployeeFormScreenState();
}

class _EmployeeFormScreenState extends State<EmployeeFormScreen> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _aadhaarName = TextEditingController();
  final _aadhaarNo = TextEditingController();
  final _phone = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  late final TextEditingController _pincode = TextEditingController(text: widget.defaultPin);
  final _experience = TextEditingController(text: '1');
  final _rate = TextEditingController(text: '300');

  List<_Rec> _services = [];
  bool _loadingServices = true;
  final Set<String> _selected = {};

  TimeOfDay _start = const TimeOfDay(hour: 9, minute: 0);
  TimeOfDay _end = const TimeOfDay(hour: 18, minute: 0);
  bool _confirmShift = false;
  bool _consent = false;
  bool _terms = false;
  bool _hidePassword = true;

  Uint8List? _aadhaarBytes;
  String _aadhaarFile = 'aadhaar.jpg';
  Uint8List? _selfieBytes;

  bool _busy = false;
  String _progress = '';
  String? _formError;
  String? _createdId; // set once the login exists, so a retry does not create it twice

  @override
  void initState() {
    super.initState();
    _loadServices();
  }

  @override
  void dispose() {
    for (final c in [_name, _aadhaarName, _aadhaarNo, _phone, _email, _password, _pincode, _experience, _rate]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _loadServices() async {
    try {
      _services = List<_Rec>.from(await supabase.from('services').select('id, name').eq('active', true).order('name'));
    } catch (_) {}
    if (mounted) setState(() => _loadingServices = false);
  }

  int _minutes(TimeOfDay t) => t.hour * 60 + t.minute;
  String _sql(TimeOfDay t) => '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}:00';

  void _fail(String message) {
    setState(() => _formError = message);
    snack(context, message, error: true);
  }

  Future<void> _pickAadhaar() async {
    try {
      final f = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1600, imageQuality: 80);
      if (f == null) return;
      final b = await f.readAsBytes();
      setState(() {
        _aadhaarBytes = b;
        _aadhaarFile = f.name;
      });
    } catch (e) {
      if (mounted) snack(context, 'Could not open the photo: $e', error: true);
    }
  }

  Future<void> _pickSelfie() async {
    try {
      final f = await ImagePicker().pickImage(
          source: ImageSource.camera, preferredCameraDevice: CameraDevice.front, maxWidth: 1000, imageQuality: 80);
      if (f == null) return;
      final b = await f.readAsBytes();
      setState(() => _selfieBytes = b);
    } catch (e) {
      if (mounted) snack(context, 'Could not open the camera: $e', error: true);
    }
  }

  Future<void> _pickTime(bool isStart) async {
    final t = await showTimePicker(context: context, initialTime: isStart ? _start : _end);
    if (t != null) setState(() => isStart ? _start = t : _end = t);
  }

  Future<void> _save() async {
    setState(() => _formError = null);
    if (!_form.currentState!.validate()) return;
    if (_selected.isEmpty) return _fail('Select at least one service this employee provides');
    if (_aadhaarBytes == null) return _fail('Upload a clear photo of the employee\'s Aadhaar card');
    if (_selfieBytes == null) return _fail('Take a clear selfie of the employee');
    if (Validators.normName(_name.text) != Validators.normName(_aadhaarName.text)) {
      return _fail('The name on the Aadhaar must match the employee name exactly');
    }
    if (_minutes(_end) <= _minutes(_start)) return _fail('Shift end time must be after the start time');
    if (!_confirmShift) return _fail('Please confirm the shift timing');
    if (!_consent) return _fail('Please accept the Aadhaar verification consent');
    if (!_terms) return _fail('Please accept the Terms and Conditions');

    setState(() {
      _busy = true;
      _progress = 'Checking pincode...';
    });
    try {
      final pin = await PincodeService.lookup(_pincode.text);
      if (pin == null) throw 'We could not find this pincode. Check it and try again.';
      final me = supabase.auth.currentUser;
      if (me == null) throw 'You are logged out. Please log in again.';

      if (_createdId == null) {
        setState(() => _progress = 'Creating the employee login...');
        final id = await supabase.rpc('institution_add_employee', params: {
          'p_name': _name.text.trim(),
          'p_email': _email.text.trim(),
          'p_phone': _phone.text.trim(),
          'p_password': _password.text,
          'p_pincode': pin.pincode,
          'p_lat': pin.lat,
          'p_lng': pin.lng,
          'p_rate': double.parse(_rate.text.trim()),
          'p_experience': int.parse(_experience.text.trim()),
          'p_services': _selected.toList(),
        });
        _createdId = '$id';
      }

      // Documents are stored in the owner's private folder (only the owner and admins can read them).
      final stamp = DateTime.now().millisecondsSinceEpoch;
      final isPng = _aadhaarFile.toLowerCase().endsWith('.png');
      setState(() => _progress = 'Uploading Aadhaar photo privately...');
      final aPath = '${me.id}/emp_${_createdId}_aadhaar_$stamp.${isPng ? 'png' : 'jpg'}';
      await supabase.storage.from('kyc').uploadBinary(aPath, _aadhaarBytes!,
          fileOptions: FileOptions(contentType: isPng ? 'image/png' : 'image/jpeg'));
      setState(() => _progress = 'Uploading selfie privately...');
      final sPath = '${me.id}/emp_${_createdId}_selfie_$stamp.jpg';
      await supabase.storage
          .from('kyc')
          .uploadBinary(sPath, _selfieBytes!, fileOptions: const FileOptions(contentType: 'image/jpeg'));

      setState(() => _progress = 'Saving the application...');
      final digits = _aadhaarNo.text.replaceAll(RegExp(r'\s'), '');
      await supabase.rpc('institution_employee_kyc', params: {
        'p_employee': _createdId,
        'p_last4': digits.substring(8),
        'p_aadhaar_name': _aadhaarName.text.trim(),
        'p_aadhaar_path': aPath,
        'p_selfie_path': sPath,
        'p_shift_start': _sql(_start),
        'p_shift_end': _sql(_end),
        'p_consent': _consent,
      });

      if (mounted) {
        Navigator.pop(context, {'name': _name.text.trim(), 'email': _email.text.trim().toLowerCase(), 'password': _password.text});
      }
    } on PostgrestException catch (e) {
      if (mounted) _fail(_createdId == null ? e.message : 'Saved partly: ${e.message}. Tap the button again to retry.');
    } on StorageException catch (e) {
      if (mounted) _fail('Photo upload failed: ${e.message}. Tap the button again to retry.');
    } catch (e) {
      if (mounted) _fail('$e');
    } finally {
      if (mounted) {
        setState(() {
          _busy = false;
          _progress = '';
        });
      }
    }
  }

  static const _termsText = '''1. Eligibility: The employee is 18 or older and the details, Aadhaar and selfie given are true and their own.

2. Verification: Fixeaze may verify identity and background. The employee can accept jobs only after approval, and approval can be withdrawn at any time.

3. Work: The employee works for the institution as a service provider on Fixeaze. They must arrive on time, work safely, treat customers with respect and never ask customers for payment outside the app.

4. Payouts: Payments for the employee's jobs are made to the institution's bank account / UPI, not to the employee.

5. Conduct: Fake details, harassment, theft, damage caused by negligence or misuse of customer information can lead to removal and legal action.

6. Privacy: Fixeaze uses these documents only for verification and keeps them private.''';

  void _showTerms() => showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Terms and Conditions'),
          content: const SingleChildScrollView(child: Text(_termsText)),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close'))],
        ),
      );

  Widget _section(String text) => Padding(
        padding: const EdgeInsets.only(top: 20, bottom: 8),
        child: Text(text, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: kTeal)),
      );

  Widget _gap() => const SizedBox(height: 12);

  Widget _photoBox(String title, Widget? preview, VoidCallback onTap, IconData icon, String label, String note) =>
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
            color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.black12)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          if (preview != null) ...[Center(child: preview), const SizedBox(height: 8)],
          OutlinedButton.icon(onPressed: onTap, icon: Icon(icon), label: Text(label)),
          const SizedBox(height: 4),
          Text(note, style: const TextStyle(fontSize: 12, color: Colors.black54)),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add employee')),
      body: Constrained(
        maxWidth: 600,
        child: Form(
          key: _form,
          child: ListView(padding: const EdgeInsets.all(16), children: [
            const Text(
              'Fill in the employee\'s details like a normal technician application. '
              'No bank account is needed: all payments go to your institution.',
              style: TextStyle(color: Colors.black54),
            ),
            _section('About the employee'),
            TextFormField(
              controller: _name,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(labelText: 'Full name (account name)', prefixIcon: Icon(Icons.badge)),
              validator: (v) => (v == null || v.trim().length < 3) ? 'Enter the full name' : null,
            ),
            _gap(),
            TextFormField(
              controller: _phone,
              keyboardType: TextInputType.phone,
              maxLength: 10,
              decoration: const InputDecoration(labelText: 'Contact number', prefixIcon: Icon(Icons.phone), counterText: ''),
              validator: (v) => RegExp(r'^[6-9][0-9]{9}$').hasMatch((v ?? '').trim()) ? null : 'Enter a valid 10-digit number',
            ),
            _gap(),
            TextFormField(
              controller: _email,
              keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(labelText: 'Email (the employee logs in with this)', prefixIcon: Icon(Icons.email)),
              validator: (v) => (v == null || !Validators.email(v)) ? 'Enter a valid email' : null,
            ),
            _gap(),
            TextFormField(
              controller: _password,
              obscureText: _hidePassword,
              decoration: InputDecoration(
                labelText: 'Password for the employee',
                prefixIcon: const Icon(Icons.lock),
                suffixIcon: IconButton(
                  icon: Icon(_hidePassword ? Icons.visibility : Icons.visibility_off),
                  onPressed: () => setState(() => _hidePassword = !_hidePassword),
                ),
              ),
              validator: (v) => (v == null || v.length < 6) ? 'At least 6 characters' : null,
            ),
            _gap(),
            TextFormField(
              controller: _pincode,
              keyboardType: TextInputType.number,
              maxLength: 6,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: const InputDecoration(
                  labelText: 'Pincode where the employee works',
                  helperText: 'Jobs come from within 10 km of this pincode',
                  prefixIcon: Icon(Icons.pin_drop),
                  counterText: ''),
              validator: (v) => (v == null || !PincodeService.isValid(v)) ? 'Enter a valid 6-digit pincode' : null,
            ),
            _section('Aadhaar verification'),
            TextFormField(
              controller: _aadhaarName,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(labelText: 'Name exactly as on Aadhaar', prefixIcon: Icon(Icons.perm_identity)),
              validator: (v) => (v == null || v.trim().length < 3) ? 'Enter the name on the Aadhaar' : null,
            ),
            _gap(),
            TextFormField(
              controller: _aadhaarNo,
              keyboardType: TextInputType.number,
              maxLength: 14,
              decoration: const InputDecoration(
                  labelText: 'Aadhaar number',
                  helperText: 'Only the last 4 digits are stored',
                  prefixIcon: Icon(Icons.credit_card),
                  counterText: ''),
              validator: (v) => Validators.aadhaar(v ?? '') ? null : 'Enter a valid 12-digit Aadhaar number',
            ),
            _gap(),
            _photoBox(
              'Aadhaar card photo',
              _aadhaarBytes == null ? null : ClipRRect(borderRadius: BorderRadius.circular(8), child: DarkSafe(child: Image.memory(_aadhaarBytes!, height: 140))),
              _pickAadhaar,
              Icons.upload_file,
              _aadhaarBytes == null ? 'Upload Aadhaar photo' : 'Change photo',
              'Clear, all four corners visible. Stored privately.',
            ),
            _section('Selfie'),
            _photoBox(
              'Employee selfie',
              _selfieBytes == null ? null : ClipOval(child: DarkSafe(child: Image.memory(_selfieBytes!, height: 120, width: 120, fit: BoxFit.cover))),
              _pickSelfie,
              Icons.photo_camera_front,
              _selfieBytes == null ? 'Take selfie' : 'Retake selfie',
              'Face clearly visible, good light. Compared with the Aadhaar photo. Stored privately.',
            ),
            _section('Work'),
            Row(children: [
              Expanded(
                child: TextFormField(
                  controller: _experience,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Experience (years)', prefixIcon: Icon(Icons.work_history)),
                  validator: (v) => int.tryParse((v ?? '').trim()) == null ? 'Number' : null,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextFormField(
                  controller: _rate,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Hourly rate (₹)', prefixIcon: Icon(Icons.currency_rupee)),
                  validator: (v) => (double.tryParse((v ?? '').trim()) ?? 0) <= 0 ? 'Enter a rate' : null,
                ),
              ),
            ]),
            _section('Services this employee provides'),
            if (_loadingServices)
              const Center(child: CircularProgressIndicator())
            else
              Wrap(spacing: 8, runSpacing: 4, children: [
                for (final s in _services)
                  FilterChip(
                    label: Text('${s['name']}'),
                    selected: _selected.contains('${s['id']}'),
                    onSelected: (v) => setState(() => v ? _selected.add('${s['id']}') : _selected.remove('${s['id']}')),
                  ),
              ]),
            _section('Shift timing'),
            Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                    onPressed: () => _pickTime(true), icon: const Icon(Icons.schedule), label: Text('Start ${_start.format(context)}')),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton.icon(
                    onPressed: () => _pickTime(false), icon: const Icon(Icons.schedule), label: Text('End ${_end.format(context)}')),
              ),
            ]),
            CheckboxListTile(
              value: _confirmShift,
              onChanged: (v) => setState(() => _confirmShift = v ?? false),
              contentPadding: EdgeInsets.zero,
              controlAffinity: ListTileControlAffinity.leading,
              title: const Text('I confirm this shift timing'),
            ),
            CheckboxListTile(
              value: _consent,
              onChanged: (v) => setState(() => _consent = v ?? false),
              contentPadding: EdgeInsets.zero,
              controlAffinity: ListTileControlAffinity.leading,
              title: const Text('The employee agrees that Fixeaze may use the Aadhaar details only to verify identity'),
            ),
            CheckboxListTile(
              value: _terms,
              onChanged: (v) => setState(() => _terms = v ?? false),
              contentPadding: EdgeInsets.zero,
              controlAffinity: ListTileControlAffinity.leading,
              title: Row(children: [
                const Flexible(child: Text('I accept the ')),
                InkWell(
                  onTap: _showTerms,
                  child: const Text('Terms and Conditions', style: TextStyle(color: kTeal, decoration: TextDecoration.underline)),
                ),
              ]),
            ),
            if (_formError != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(_formError!, style: const TextStyle(color: Colors.red, fontWeight: FontWeight.w600)),
              ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: _busy ? null : _save,
              child: _busy
                  ? Row(mainAxisSize: MainAxisSize.min, children: [
                      const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)),
                      const SizedBox(width: 10),
                      Text(_progress.isEmpty ? 'Please wait...' : _progress),
                    ])
                  : Text(_createdId == null ? 'Create employee' : 'Retry saving'),
            ),
            const SizedBox(height: 30),
          ]),
        ),
      ),
    );
  }
}
