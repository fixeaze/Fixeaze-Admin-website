import 'dart:convert';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:supabase_flutter/supabase_flutter.dart' show FileOptions, FunctionException, SearchOptions;

import '../config.dart';
import '../services/file_save.dart';
import 'admin_util.dart';
import 'admin_widgets.dart';

// ============================================================ BACKUP (CSV ZIP)

const _backupTables = <String, String>{
  'profiles': 'All accounts (customers, technicians, admins)',
  'technician_profiles': 'Technician details and rates',
  'technician_services': 'Services each technician offers',
  'technician_kyc': 'Technician KYC records',
  'services': 'Service list',
  'bookings': 'All bookings',
  'job_parts': 'Spare parts used on jobs',
  'reviews': 'Customer ratings of technicians',
  'customer_reviews': 'Technician ratings of customers',
  'cancellations': 'Cancellations with reasons',
  'technician_payments': 'Technician payments',
  'institutions': 'Institution accounts',
  'messages': 'Booking chats',
  'admin_chat': 'Admin chat',
  'tech_chat': 'Technician support chat',
  'sos_alerts': 'SOS alerts',
  'maintenance_tips': 'Maintenance tips',
  'catalog_products': 'Catalog products',
  'product_services': 'Catalog service types',
  'technician_prices': 'Technician charges',
  'offers': 'Offers',
  'offer_redemptions': 'Offers used by customers',
  'incentive_awards': 'Technician incentives',
  'technician_login_days': 'Technician login days',
};

String _csvCell(dynamic v) {
  var s = v == null ? '' : (v is Map || v is List ? jsonEncode(v) : '$v');
  if (RegExp(r'^[=@]').hasMatch(s) || RegExp(r'^[+\-](?![\d\s]*$)').hasMatch(s)) s = "'$s";
  if (s.contains(',') || s.contains('"') || s.contains('\n') || s.contains('\r')) {
    s = '"${s.replaceAll('"', '""')}"';
  }
  return s;
}

class BackupPage extends StatefulWidget {
  const BackupPage({super.key});
  @override
  State<BackupPage> createState() => _BackupPageState();
}

class _BackupPageState extends State<BackupPage> {
  bool _busy = false;
  String _status = '';
  final List<String> _log = [];

  Future<List<Map<String, dynamic>>> _dump(String table) async {
    final out = <Map<String, dynamic>>[];
    for (var from = 0; from < 200000; from += 1000) {
      List data;
      try {
        data = await supabase.from(table).select('*').order('id').range(from, from + 999) as List;
      } catch (_) {
        data = await supabase.from(table).select('*').range(from, from + 999) as List;
      }
      final l = data.map((e) => Map<String, dynamic>.from(e as Map)).toList();
      out.addAll(l);
      if (l.length < 1000) break;
    }
    return out;
  }

  int _zipRows = 0;

  Future<void> _logBackup(String kind) async {
    try {
      await supabase.from('backup_log').insert({'kind': kind});
    } catch (_) {}
  }

  Future<Uint8List> _makeDataZip() async {
    final archive = Archive();
    var total = 0;
    for (final t in _backupTables.keys) {
      setState(() => _status = 'Reading $t ...');
      try {
        final rows = await _dump(t);
        final cols = <String>[];
        for (final r in rows) {
          for (final k in r.keys) {
            if (!cols.contains(k)) cols.add(k);
          }
        }
        final sb = StringBuffer('\u{FEFF}${cols.map(_csvCell).join(',')}\r\n');
        for (final r in rows) {
          sb.write('${cols.map((c) => _csvCell(r[c])).join(',')}\r\n');
        }
        final bytes = Uint8List.fromList(utf8.encode(sb.toString()));
        archive.addFile(ArchiveFile('$t.csv', bytes.length, bytes));
        total += rows.length;
        _log.add('$t: ${rows.length} rows');
      } catch (_) {
        _log.add('$t: skipped (not found or no access)');
      }
    }
    setState(() => _status = 'Creating the ZIP file ...');
    final zip = ZipEncoder().encode(archive);
    _zipRows = total;
    return Uint8List.fromList(zip ?? <int>[]);
  }

  Future<void> _run() async {
    setState(() {
      _busy = true;
      _log.clear();
      _status = 'Starting...';
    });
    final bytes = await _makeDataZip();
    final name = 'fixeaze_backup_${dkey(DateTime.now())}.zip';
    await saveBytes(name, bytes, 'application/zip');
    await _logBackup('download');
    if (mounted) {
      setState(() {
        _busy = false;
        _status = 'Done. $name saved ($_zipRows rows). Upload it to Google Drive.';
      });
    }
  }

  int _keepMonths = 12;
  List<Map<String, dynamic>> _preview = [];

  Future<void> _cleanup(bool apply) async {
    if (apply) {
      final go = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Delete old data?'),
          content: Text('Everything listed below that is older than $_keepMonths months will be deleted for good. '
              'Make sure your backup is saved in Google Drive.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(
                style: FilledButton.styleFrom(backgroundColor: Colors.red),
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Delete')),
          ],
        ),
      );
      if (go != true) return;
    }
    setState(() {
      _busy = true;
      _status = apply ? 'Deleting ...' : 'Counting ...';
    });
    try {
      final r = await supabase.rpc('admin_cleanup_old_data', params: {'p_months': _keepMonths, 'p_apply': apply});
      _preview = List<Map<String, dynamic>>.from(r as List);
      final total = _preview.fold<int>(0, (a, e) => a + ((e['n'] as num?)?.toInt() ?? 0));
      _status = apply ? 'Done. $total old rows deleted.' : '$total old rows can be deleted.';
    } catch (e) {
      _status = 'Clean-up failed: ${e is Exception ? e.toString().replaceFirst('Exception: ', '') : e}';
    }
    if (mounted) setState(() => _busy = false);
  }

  static const _months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  Future<void> _email() async {
    final now = DateTime.now();
    final subject = 'Data for ${_months[now.month - 1]} ${now.year}';
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Email the backup?'),
        content: Text('Subject: "$subject"\n\nSent to:\n${_mailTo.join('\n')}\n\n'
            'The data ZIP is attached. It has personal details, so only send it to these team addresses.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Send email')),
        ],
      ),
    );
    if (ok != true) return;
    setState(() {
      _busy = true;
      _log.clear();
      _status = 'Starting...';
    });
    try {
      final bytes = await _makeDataZip();
      final path = 'backup_${dkey(now)}_${now.millisecondsSinceEpoch}.zip';
      setState(() => _status = 'Uploading ...');
      await supabase.storage.from('backups').uploadBinary(path, bytes,
          fileOptions: const FileOptions(contentType: 'application/zip'));
      setState(() => _status = 'Sending the email ...');
      await supabase.functions.invoke('send-backup', body: {'path': path, 'subject': subject});
      await _logBackup('email');
      if (mounted) setState(() => _status = 'Email sent: "$subject" ($_zipRows rows).');
    } on FunctionException catch (e) {
      if (mounted) setState(() => _status = 'Email failed: ${e.details ?? e.reasonPhrase}');
    } catch (e) {
      if (mounted) setState(() => _status = 'Email failed: $e');
    }
    if (mounted) setState(() => _busy = false);
  }

  static const _mailTo = [
    'diveaniruddha@fixeaze.com',
    'support@fixeaze.com',
    'tejasvi.mhatre@fixeaze.com',
    'parag.pendhari@fixeaze.com',
  ];

  // ---------------------------------------------------------- files (images)
  Future<void> _addUrl(Archive a, String url, String name) async {
    final r = await http.get(Uri.parse(url));
    if (r.statusCode == 200) {
      a.addFile(ArchiveFile(name, r.bodyBytes.length, r.bodyBytes));
    } else {
      throw Exception('HTTP ${r.statusCode}');
    }
  }

  Future<void> _listKyc(String prefix, List<String> out, [int depth = 0]) async {
    if (depth > 4) return;
    final items = await supabase.storage.from('kyc').list(path: prefix, searchOptions: const SearchOptions(limit: 1000));
    for (final it in items) {
      final full = prefix.isEmpty ? it.name : '$prefix/${it.name}';
      if (it.id == null) {
        await _listKyc(full, out, depth + 1);
      } else {
        out.add(full);
      }
    }
  }

  Future<void> _finish(Archive a, String prefix, int ok, int bad) async {
    setState(() => _status = 'Creating the ZIP file ...');
    final zip = ZipEncoder().encode(a);
    final name = '${prefix}_${dkey(DateTime.now())}.zip';
    await saveBytes(name, Uint8List.fromList(zip ?? <int>[]), 'application/zip');
    if (mounted) {
      setState(() {
        _busy = false;
        _status = 'Done. $name saved ($ok files${bad > 0 ? ', $bad could not be downloaded' : ''}). Upload it to Google Drive.';
      });
    }
  }

  Future<void> _runKyc() async {
    setState(() {
      _busy = true;
      _log.clear();
      _status = 'Listing KYC documents ...';
    });
    final a = Archive();
    var ok = 0, bad = 0;
    try {
      final paths = <String>[];
      await _listKyc('', paths);
      for (var i = 0; i < paths.length; i++) {
        setState(() => _status = 'Downloading ${i + 1} of ${paths.length} ...');
        try {
          final url = await supabase.storage.from('kyc').createSignedUrl(paths[i], 300);
          await _addUrl(a, url, 'kyc/${paths[i]}');
          ok++;
        } catch (_) {
          bad++;
          _log.add('Failed: ${paths[i]}');
        }
      }
    } catch (e) {
      _log.add('Could not read the kyc bucket: $e');
    }
    await _finish(a, 'fixeaze_kyc_documents', ok, bad);
  }

  static final _imgRe = RegExp(r'^https?://res\.cloudinary\.com/');

  void _collect(dynamic v, Set<String> out) {
    if (v is String && _imgRe.hasMatch(v)) out.add(v);
    if (v is List) {
      for (final x in v) {
        _collect(x, out);
      }
    }
  }

  Future<void> _runPhotos() async {
    setState(() {
      _busy = true;
      _log.clear();
      _status = 'Finding photos ...';
    });
    final urls = <String>{};
    for (final t in const [
      'profiles', 'technician_profiles', 'bookings', 'institutions', 'admin_chat', 'tech_chat', 'messages', 'sos_alerts'
    ]) {
      try {
        for (final r in await _dump(t)) {
          for (final v in r.values) {
            _collect(v, urls);
          }
        }
      } catch (_) {}
    }
    final a = Archive();
    var ok = 0, bad = 0, n = 0;
    final list = urls.toList();
    for (final u in list) {
      n++;
      setState(() => _status = 'Downloading $n of ${list.length} ...');
      try {
        final base = Uri.parse(u).pathSegments.last;
        final ext = base.contains('.') ? '' : '.jpg';
        await _addUrl(a, u, 'photos/${n.toString().padLeft(5, '0')}_$base$ext');
        ok++;
      } catch (_) {
        bad++;
      }
    }
    await _finish(a, 'fixeaze_photos', ok, bad);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      const NoticeBanner(
          'Download this once a month and keep the ZIP in Google Drive. '
          'The data ZIP has all records. Use the buttons below for KYC documents and photos.'),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Download all data', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            const Text('One ZIP with a CSV file for every table. Opens in Excel or Google Sheets.'),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: _busy ? null : _run,
              icon: _busy
                  ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.download),
              label: Text(_busy ? 'Working...' : 'Download full backup (ZIP)'),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _busy ? null : _email,
              icon: const Icon(Icons.email_outlined),
              label: const Text('Email the backup to the team'),
            ),
            if (_status.isNotEmpty) ...[
              const SizedBox(height: 10),
              Text(_status, style: const TextStyle(fontWeight: FontWeight.w600)),
            ],
            for (final l in _log) Text(l, style: const TextStyle(fontSize: 12, color: Colors.black54)),
          ]),
        ),
      ),
      const SizedBox(height: 12),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Download images and documents', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            const Text('KYC documents and selfies, and all photos (profile pictures, job photos, chat photos). '
                'Best done on a computer. If you have thousands of files it can take a few minutes.'),
            const SizedBox(height: 12),
            Wrap(spacing: 10, runSpacing: 8, children: [
              OutlinedButton.icon(
                onPressed: _busy ? null : _runKyc,
                icon: const Icon(Icons.badge_outlined),
                label: const Text('KYC documents (ZIP)'),
              ),
              OutlinedButton.icon(
                onPressed: _busy ? null : _runPhotos,
                icon: const Icon(Icons.photo_library_outlined),
                label: const Text('Photos (ZIP)'),
              ),
            ]),
          ]),
        ),
      ),
      const SizedBox(height: 12),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Free up space (after backup)', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            const Text('Deletes only old chat messages, technician notifications and admin activity logs. '
                'Bookings, payments, ratings, accounts and invoices are never deleted. '
                'It only works if you downloaded or emailed a backup in the last 2 days.'),
            const SizedBox(height: 12),
            Row(children: [
              const Text('Delete older than  '),
              DropdownButton<int>(
                value: _keepMonths,
                items: const [
                  DropdownMenuItem(value: 3, child: Text('3 months')),
                  DropdownMenuItem(value: 6, child: Text('6 months')),
                  DropdownMenuItem(value: 12, child: Text('12 months')),
                  DropdownMenuItem(value: 24, child: Text('24 months')),
                ],
                onChanged: _busy ? null : (v) => setState(() => _keepMonths = v ?? 12),
              ),
            ]),
            Wrap(spacing: 10, runSpacing: 8, children: [
              OutlinedButton(onPressed: _busy ? null : () => _cleanup(false), child: const Text('Preview what will go')),
              FilledButton(
                  style: FilledButton.styleFrom(backgroundColor: Colors.red),
                  onPressed: _busy ? null : () => _cleanup(true),
                  child: const Text('Delete old data')),
            ]),
            for (final r in _preview) Text('• ${r['item']}: ${r['n']}'),
          ]),
        ),
      ),
      const SizedBox(height: 12),
      const SectionTitle('What is included'),
      for (final e in _backupTables.entries) Text('• ${e.value}  (${e.key}.csv)'),
    ]);
  }
}
