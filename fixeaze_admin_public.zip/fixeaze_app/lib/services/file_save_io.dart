import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';

/// Phone / desktop: asks where to save the file.
Future<bool> saveBytes(String fileName, Uint8List bytes, String mime) async {
  final path = await FilePicker.platform.saveFile(fileName: fileName, bytes: bytes);
  return path != null;
}
