import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'services/native_push.dart';

class AppState {
  /// True when the visitor tapped "Skip for now" and is browsing without an account.
  static final ValueNotifier<bool> guest = ValueNotifier<bool>(false);
}

Future<void> signOutAll() async {
  AppState.guest.value = false;
  await NativePush.forgetThisPhone();
  await Supabase.instance.client.auth.signOut();
}
