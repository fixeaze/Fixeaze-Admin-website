import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';
import '../widgets/chat_media.dart';
import '../widgets/common.dart';

/// A booking chat is open while the job is running and for 7 days after it is done.
bool chatIsOpen(Map<String, dynamic> b) {
  final s = (b['status'] ?? '').toString();
  if (s == 'accepted' || s == 'in_progress') return true;
  if (s != 'completed') return false;
  final f = DateTime.tryParse('${b['finished_at'] ?? ''}');
  return f != null && DateTime.now().difference(f.toLocal()) < const Duration(days: 7);
}

/// Live chat between the customer and the technician of one booking.
class ChatScreen extends StatefulWidget {
  final String bookingId;
  final String title;
  final bool canSend;
  const ChatScreen({
    super.key,
    required this.bookingId,
    required this.title,
    this.canSend = true,
  });

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _text = TextEditingController();
  final _scroll = ScrollController();
  late final Stream<List<Map<String, dynamic>>> _stream;
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    _stream = supabase
        .from('messages')
        .stream(primaryKey: ['id'])
        .eq('booking_id', widget.bookingId)
        .order('created_at', ascending: true);
  }

  @override
  void dispose() {
    _text.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final body = _text.text.trim();
    if (body.isEmpty || _sending) return;
    setState(() => _sending = true);
    try {
      await supabase.from('messages').insert({
        'booking_id': widget.bookingId,
        'sender_id': supabase.auth.currentUser!.id,
        'body': body,
      });
      _text.clear();
    } on PostgrestException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    } catch (e) {
      if (mounted) snack(context, 'Message not sent: $e', error: true);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _attach() async {
    if (_sending) return;
    setState(() => _sending = true);
    try {
      final a = await pickChatAttachment(context);
      if (a != null) {
        await supabase.from('messages').insert({
          'booking_id': widget.bookingId,
          'sender_id': supabase.auth.currentUser!.id,
          'body': a.type == 'image' ? '📷 Photo' : a.type == 'video' ? '🎥 Video' : '📎 ${a.name}',
          'media_url': a.url,
          'media_type': a.type,
          'media_name': a.name,
        });
      }
    } on PostgrestException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    } catch (e) {
      if (mounted) snack(context, 'Not sent: $e', error: true);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  void _scrollToEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.jumpTo(_scroll.position.maxScrollExtent);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final me = supabase.auth.currentUser?.id;
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Constrained(
        maxWidth: 700,
        child: Column(
          children: [
            Expanded(
              child: StreamBuilder<List<Map<String, dynamic>>>(
                stream: _stream,
                builder: (context, snap) {
                  if (snap.hasError) {
                    return Center(child: Text('Could not load messages.\n${snap.error}'));
                  }
                  if (!snap.hasData) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  final msgs = snap.data!;
                  if (msgs.isEmpty) {
                    return const EmptyState(
                      icon: Icons.chat_bubble_outline,
                      text: 'No messages yet.\nSay hello!',
                    );
                  }
                  _scrollToEnd();
                  return ListView.builder(
                    controller: _scroll,
                    padding: const EdgeInsets.all(12),
                    itemCount: msgs.length,
                    itemBuilder: (context, i) {
                      final m = msgs[i];
                      final mine = m['sender_id'] == me;
                      final time = m['created_at'] == null
                          ? ''
                          : DateFormat('h:mm a')
                              .format(DateTime.parse(m['created_at'].toString()).toLocal());
                      return Align(
                        alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                        child: Container(
                          margin: const EdgeInsets.symmetric(vertical: 4),
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          constraints: const BoxConstraints(maxWidth: 300),
                          decoration: BoxDecoration(
                            color: mine ? Colors.teal.shade600 : Colors.white,
                            borderRadius: BorderRadius.circular(14),
                            border: mine ? null : Border.all(color: Colors.black12),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              if ((m['media_url'] ?? '').toString().isNotEmpty) ...[
                                ChatMedia(
                                  url: m['media_url'].toString(),
                                  type: (m['media_type'] ?? 'file').toString(),
                                  name: (m['media_name'] ?? '').toString(),
                                  mine: mine,
                                ),
                                const SizedBox(height: 4),
                              ] else
                                Text(
                                  (m['body'] ?? '').toString(),
                                  style: TextStyle(
                                      color: mine ? Colors.white : Colors.black87),
                                ),
                              const SizedBox(height: 2),
                              Text(
                                time,
                                style: TextStyle(
                                    fontSize: 10,
                                    color: mine ? Colors.white70 : Colors.black45),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
            if (widget.canSend)
              SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
                  child: Row(
                    children: [
                      IconButton(
                        onPressed: _sending ? null : _attach,
                        icon: const Icon(Icons.attach_file),
                        tooltip: 'Send photo, video or file',
                      ),
                      Expanded(
                        child: TextField(
                          controller: _text,
                          minLines: 1,
                          maxLines: 4,
                          maxLength: 1000,
                          textInputAction: TextInputAction.send,
                          decoration: const InputDecoration(
                            hintText: 'Type a message',
                            counterText: '',
                          ),
                          onSubmitted: (_) => _send(),
                        ),
                      ),
                      const SizedBox(width: 8),
                      IconButton.filled(
                        onPressed: _sending ? null : _send,
                        icon: const Icon(Icons.send),
                      ),
                    ],
                  ),
                ),
              )
            else
              const Padding(
                padding: EdgeInsets.all(12),
                child: Text('This chat is closed. It stays open for 7 days after the job is done.',
                    style: TextStyle(color: Colors.black54)),
              ),
          ],
        ),
      ),
    );
  }
}
