/// Website build: no phone notifications here (the website has its own push).
class NativePush {
  static Future<void> start({bool admin = false}) async {}
  static Future<void> forgetThisPhone() async {}
}
