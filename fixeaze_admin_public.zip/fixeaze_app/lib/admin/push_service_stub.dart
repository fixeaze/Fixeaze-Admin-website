import 'package:flutter/material.dart';

import '../config.dart';
import 'admin_widgets.dart';

/// Phone / desktop build of the admin app: the browser notification helper does not exist here.
class PushService {
  static const vapidPublicKey = '';
  static bool get supported => false;
  static String get permission => 'unsupported';
  static Future<String?> playSound(String kind) async => null;
  static Future<String?> enable({bool ask = true}) async =>
      'Browser notifications are only for the website. Use the admin website on this phone for alerts.';
  static Future<void> refreshIfGranted() async {}
}

class NotificationsPage extends StatefulWidget {
  const NotificationsPage({super.key});
  @override
  State<NotificationsPage> createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  String _msg = '';
  bool _busy = false;
  int? _phones;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final n = await supabase.rpc('admin_my_phones');
      if (mounted) setState(() => _phones = (n as num).toInt());
    } catch (_) {}
  }

  Future<void> _test() async {
    setState(() {
      _busy = true;
      _msg = '';
    });
    try {
      await supabase.rpc('admin_push_test');
      _msg = 'Test sent. It should arrive in a few seconds. Close the app and try again to check alerts while it is closed.';
    } catch (e) {
      _msg = 'Could not send the test: $e';
    }
    await _load();
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        SectionCard(
          title: 'Phone notifications',
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Muted('This phone gets alerts for SOS, bookings, tickets and chats, even when the app is closed.'),
            const SizedBox(height: 10),
            Text(_phones == null
                ? 'Checking this phone ...'
                : _phones == 0
                    ? 'This phone is NOT registered yet. Open the app once with internet, allow notifications, then check again.'
                    : 'Registered phones for your login: $_phones'),
            const SizedBox(height: 12),
            Wrap(spacing: 10, runSpacing: 8, children: [
              FilledButton.icon(
                  onPressed: _busy ? null : _test,
                  icon: const Icon(Icons.notifications_active_outlined),
                  label: Text(_busy ? 'Sending ...' : 'Send a test notification')),
              OutlinedButton.icon(
                  onPressed: _busy ? null : _load,
                  icon: const Icon(Icons.refresh),
                  label: const Text('Check again')),
            ]),
            if (_msg.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 10), child: Text(_msg)),
          ]),
        ),
      ],
    );
  }
}
