import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import '../dark_mode.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/cloudinary_service.dart';

class ChatAttachment {
  final String url, type, name; // type: image | video | file
  const ChatAttachment(this.url, this.type, this.name);
}

/// Lets the person choose Photo / Video / File, uploads it and returns the link.
Future<ChatAttachment?> pickChatAttachment(BuildContext context) async {
  final kind = await showModalBottomSheet<String>(
    context: context,
    builder: (ctx) => SafeArea(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        ListTile(leading: const Icon(Icons.image), title: const Text('Photo'), onTap: () => Navigator.pop(ctx, 'image')),
        ListTile(leading: const Icon(Icons.videocam), title: const Text('Video'), onTap: () => Navigator.pop(ctx, 'video')),
        ListTile(leading: const Icon(Icons.attach_file), title: const Text('File (PDF, document...)'), onTap: () => Navigator.pop(ctx, 'file')),
      ]),
    ),
  );
  if (kind == null) return null;
  Uint8List? bytes;
  String name = 'file';
  if (kind == 'file') {
    final r = await FilePicker.platform.pickFiles(withData: true);
    if (r == null || r.files.isEmpty || r.files.first.bytes == null) return null;
    bytes = r.files.first.bytes;
    name = r.files.first.name;
  } else {
    final picker = ImagePicker();
    final XFile? f = kind == 'image'
        ? await picker.pickImage(source: ImageSource.gallery, maxWidth: 1600, imageQuality: 80)
        : await picker.pickVideo(source: ImageSource.gallery);
    if (f == null) return null;
    bytes = await f.readAsBytes();
    name = f.name;
  }
  if (bytes!.length > 40 * 1024 * 1024) throw Exception('That file is too large (max 40 MB).');
  final url = await CloudinaryService.uploadAny(bytes, name);
  return ChatAttachment(url, kind, name);
}

/// Photo / video / file shown inside a chat bubble.
class ChatMedia extends StatelessWidget {
  final String url, type, name;
  final bool mine;
  const ChatMedia({super.key, required this.url, required this.type, required this.name, this.mine = false});

  String get _thumb {
    var u = url.replaceFirst('/upload/', '/upload/so_0,w_480,c_limit/');
    final dot = u.lastIndexOf('.');
    if (dot > u.lastIndexOf('/')) u = '${u.substring(0, dot)}.jpg';
    return u;
  }

  Future<void> _open() => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);

  @override
  Widget build(BuildContext context) {
    if (type == 'image') {
      return GestureDetector(
        onTap: () => showDialog<void>(
          context: context,
          builder: (_) => Dialog(
            child: InteractiveViewer(child: DarkSafe(child: Image.network(url, fit: BoxFit.contain))),
          ),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: DarkSafe(child: Image.network(CloudinaryService.optimized(url, width: 600),
              width: 240, fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const SizedBox(width: 240, height: 80, child: Center(child: Icon(Icons.broken_image))))),
        ),
      );
    }
    if (type == 'video') {
      return GestureDetector(
        onTap: _open,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: Stack(alignment: Alignment.center, children: [
            DarkSafe(child: Image.network(_thumb,
                width: 240, height: 150, fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(width: 240, height: 150, color: Colors.black87))),
            const CircleAvatar(backgroundColor: Colors.black54, child: Icon(Icons.play_arrow, color: Colors.white)),
          ]),
        ),
      );
    }
    return InkWell(
      onTap: _open,
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
            color: (mine ? Colors.white : Colors.teal).withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.insert_drive_file, color: mine ? Colors.white : Colors.teal),
          const SizedBox(width: 8),
          Flexible(child: Text(name.isEmpty ? 'File' : name, overflow: TextOverflow.ellipsis,
              style: TextStyle(color: mine ? Colors.white : Colors.black87, decoration: TextDecoration.underline))),
        ]),
      ),
    );
  }
}

/// Sent / delivered / seen ticks.
class Ticks extends StatelessWidget {
  final String status; // sent | delivered | seen
  final Color base;
  const Ticks(this.status, {super.key, this.base = Colors.white70});
  @override
  Widget build(BuildContext context) {
    final seen = status == 'seen';
    return Icon(status == 'sent' ? Icons.check : Icons.done_all,
        size: 15, color: seen ? Colors.lightBlueAccent : base);
  }
}
