import 'package:flutter/material.dart';
import 'job_buttons.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../config.dart';
import '../../widgets/common.dart';
import '../../widgets/job_location.dart';
import '../../widgets/cancel_dialog.dart';
import '../../widgets/verified_badge.dart';

class OpenJobsTab extends StatefulWidget {
  final VoidCallback onAccepted;
  const OpenJobsTab({super.key, required this.onAccepted});

  @override
  State<OpenJobsTab> createState() => _OpenJobsTabState();
}

class _OpenJobsTabState extends State<OpenJobsTab> {
  late Future<List<Map<String, dynamic>>> _future;
  String? _accepting; // booking id currently being accepted
  Map<String, num> _mine = {}; // my charge per item id

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  void _refresh() => setState(() => _future = _load());

  Future<List<Map<String, dynamic>>> _load() async {
    final rows = await supabase
        .from('bookings')
        .select('*, services(name, base_price), catalog_products(name), product_services(name)')
        .eq('status', 'pending')
        .isFilter('technician_id', null)
        .order('scheduled_at', ascending: true);
    var list = List<Map<String, dynamic>>.from(rows);
    try {
      final pr = await supabase
          .from('technician_prices')
          .select('item_id, price')
          .eq('technician_id', supabase.auth.currentUser!.id)
          .eq('enabled', true);
      _mine = {for (final r in pr) '${r['item_id']}': (r['price'] as num)};
    } catch (_) {}
    try {
      final c = await supabase.from('cancellations').select('booking_id').eq('by_user', supabase.auth.currentUser!.id);
      final mine = {for (final r in c) '${r['booking_id']}'};
      list = list.where((b) => !mine.contains('${b['id']}')).toList();
    } catch (_) {}
    final me = supabase.auth.currentUser?.id;
    list.sort((a, b) {
      final pa = a['preferred_technician_id'] == me ? 0 : 1;
      final pb = b['preferred_technician_id'] == me ? 0 : 1;
      return pa.compareTo(pb);
    });
    return list;
  }

  Future<void> _accept(Map<String, dynamic> b) async {
    setState(() => _accepting = b['id'] as String);
    try {
      final res = await supabase
          .from('bookings')
          .update({
            'status': 'accepted',
            'technician_id': supabase.auth.currentUser!.id,
          })
          .eq('id', b['id'])
          .eq('status', 'pending')
          .isFilter('technician_id', null)
          .select();

      if (!mounted) return;
      if (res.isEmpty) {
        snack(context, 'Sorry, another technician already took this job.', error: true);
        _refresh();
      } else {
        snack(context, 'Job accepted! Find it under My jobs.');
        widget.onAccepted();
      }
    } on PostgrestException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    } finally {
      if (mounted) setState(() => _accepting = null);
    }
  }

  Future<void> _decline(Map<String, dynamic> b) async {
    final r = await showCancelDialog(context, technician: true, decline: true);
    if (r == null) return;
    try {
      await supabase.rpc('decline_job',
          params: {'p_booking': b['id'], 'p_reason': r.reason, 'p_note': r.note});
      if (mounted) snack(context, 'Job declined. It stays open for other technicians.');
    } on PostgrestException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    }
    if (mounted) _refresh();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snap.hasError) {
          return ErrorState(error: snap.error!, onRetry: _refresh);
        }
        final jobs = snap.data!;
        if (jobs.isEmpty) {
          return RefreshIndicator(
            onRefresh: () async {
              _refresh();
              await _future;
            },
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: const [
                BadgeProgressCard(),
                SizedBox(height: 60),
                EmptyState(
                  icon: Icons.work_off,
                  text: 'No open jobs right now.\nPull down to refresh.',
                ),
              ],
            ),
          );
        }
        return RefreshIndicator(
          onRefresh: () async {
            _refresh();
            await _future;
          },
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: jobs.length + 1,
            itemBuilder: (context, i) {
              if (i == 0) return const BadgeProgressCard();
              final b = jobs[i - 1];
              final service = b['services'] as Map<String, dynamic>?;
              final photos = List<String>.from(b['photos'] ?? const []);
              final busy = _accepting == b['id'];
              return Card(
                margin: const EdgeInsets.only(bottom: 12),
                elevation: 2,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(serviceIcon((service?['name'] ?? '').toString()),
                              color: Colors.teal),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text((service?['name'] ?? 'Service').toString(),
                                style: const TextStyle(
                                    fontSize: 17, fontWeight: FontWeight.bold)),
                          ),
                          if (b['item_id'] != null && _mine['${b['item_id']}'] != null)
                            Text(money(_mine['${b['item_id']}']),
                                style: const TextStyle(
                                    fontWeight: FontWeight.w600, color: Colors.teal))
                          else if (b['item_id'] == null && service?['base_price'] != null)
                            Text(money(service!['base_price']),
                                style: const TextStyle(
                                    fontWeight: FontWeight.w600, color: Colors.teal)),
                        ],
                      ),
                      const SizedBox(height: 8),
                      if ((b['booking_no'] ?? '').toString().isNotEmpty)
                        Text('Booking ${b['booking_no']}',
                            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                      if (b['preferred_technician_id'] == supabase.auth.currentUser?.id)
                        Container(
                          margin: const EdgeInsets.only(top: 4),
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                              color: Colors.orange.withOpacity(0.15), borderRadius: BorderRadius.circular(8)),
                          child: Builder(builder: (_) {
                            final created = DateTime.tryParse('${b['created_at']}')?.toLocal();
                            final left = created == null
                                ? 30
                                : 30 - DateTime.now().difference(created).inMinutes;
                            return Text(
                                left > 0
                                    ? 'Customer chose you. Accept within $left min'
                                    : 'Customer chose you (time is over, now open to others)',
                                style: const TextStyle(fontSize: 12, color: Colors.deepOrange));
                          }),
                        ),
                      if (b['item_id'] != null)
                        Text(
                            '${(b['catalog_products'] as Map?)?['name'] ?? ''} > ${(b['product_services'] as Map?)?['name'] ?? ''}',
                            style: TextStyle(
                                color: Colors.teal.shade700,
                                fontSize: 13,
                                fontWeight: FontWeight.w600))
                      else
                      Text(bookingTypeLabel(b),
                          style: TextStyle(
                              color: Colors.teal.shade700,
                              fontSize: 12,
                              fontWeight: FontWeight.w600)),
                      const SizedBox(height: 4),
                      Row(children: [
                        const Icon(Icons.event, size: 16, color: Colors.black45),
                        const SizedBox(width: 6),
                        Expanded(child: Text(fmtDate(b['scheduled_at']))),
                      ]),
                      const SizedBox(height: 4),
                      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Icon(Icons.location_on, size: 16, color: Colors.black45),
                        const SizedBox(width: 6),
                        Expanded(child: Text((b['address'] ?? '').toString())),
                      ]),
                      JobLocation(booking: b),
                      if ((b['notes'] ?? '').toString().isNotEmpty) ...[
                        const SizedBox(height: 8),
                        Text('"${b['notes']}"',
                            style: const TextStyle(
                                fontStyle: FontStyle.italic, color: Colors.black54)),
                      ],
                      if (photos.isNotEmpty) ...[
                        const SizedBox(height: 10),
                        PhotoStrip(urls: photos),
                      ],
                      const SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        child: GoButton(
                          busy: busy,
                          onPressed: () => _accept(b),
                          icon: Icons.check_rounded,
                          label: 'Accept job',
                        ),
                      ),
                      const SizedBox(height: 10),
                      SizedBox(
                        width: double.infinity,
                        child: SoftButton(
                          compact: true,
                          color: kStopRed,
                          icon: Icons.close,
                          label: 'Decline job',
                          onPressed: busy ? null : () => _decline(b),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }
}
