import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// Warm Minimal look: cream background, deep green, serif headings.
const kTeal = Color(0xFF1F4D3A); // deep green (kept the old name so every screen follows)
const kAmber = Color(0xFFD9A441);
const kCream = Color(0xFFFBF8F2);
const kLine = Color(0xFFE5DFD1);
const kInk = Color(0xFF1F2A24);

ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: kTeal,
    primary: kTeal,
    secondary: kAmber,
    brightness: Brightness.light,
  ).copyWith(surfaceTint: Colors.transparent);
  final base = GoogleFonts.dmSansTextTheme(ThemeData.light().textTheme);
  final serif = GoogleFonts.dmSerifDisplay();
  final text = base.copyWith(
    displayLarge: serif,
    displayMedium: serif,
    displaySmall: serif,
    headlineLarge: serif,
    headlineMedium: serif,
    headlineSmall: serif,
  ).apply(bodyColor: kInk, displayColor: kInk);
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    textTheme: text,
    scaffoldBackgroundColor: kCream,
    appBarTheme: AppBarTheme(
      backgroundColor: kCream,
      foregroundColor: kInk,
      centerTitle: false,
      elevation: 0,
      scrolledUnderElevation: 0,
      titleTextStyle: GoogleFonts.dmSerifDisplay(fontSize: 22, color: kInk),
      shape: const Border(bottom: BorderSide(color: kLine)),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: kCream,
      indicatorColor: const Color(0xFFE7EFE9),
      labelTextStyle: MaterialStateProperty.resolveWith((st) => TextStyle(
            fontSize: 12,
            fontWeight: st.contains(MaterialState.selected) ? FontWeight.w800 : FontWeight.w500,
            color: st.contains(MaterialState.selected) ? kTeal : Colors.black54,
          )),
    ),
    dividerColor: kLine,
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Color(0xFFD6D0C2)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Color(0xFFD6D0C2)),
      ),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        minimumSize: const Size(88, 52),
        textStyle: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        minimumSize: const Size(88, 44),
        side: const BorderSide(color: Color(0xFFD6D0C2)),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    ),
  );
}
