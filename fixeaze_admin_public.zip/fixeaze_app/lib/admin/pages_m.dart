import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart' show PostgrestException;

import '../config.dart';
import 'admin_store.dart';
import 'admin_util.dart';
import 'admin_widgets.dart';
import 'pages_a.dart';

AdminStore get _s => AdminStore.I;

String _err(Object e) => e is PostgrestException ? e.message : '$e';

DateTime _firstOf(DateTime d) => DateTime(d.year, d.month, 1);

const _monthNames = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];
String _monthLabel(DateTime d) => '${_monthNames[d.month - 1]} ${d.year}';

// ================================================================ INCENTIVES

class IncentivesPage extends StatefulWidget {
  const IncentivesPage({super.key});
  @override
  State<IncentivesPage> createState() => _IncentivesPageState();
}

class _IncentivesPageState extends State<IncentivesPage> {
  bool _loading = true;
  bool _busy = false;
  String? _error;

  bool _enabled = false;
  String _base = 'gross';
  final _days = TextEditingController();
  final _pct = TextEditingController();
  final _creditDay = TextEditingController();

  late DateTime _month;
  DateTime? _creditOn;
  List<Map<String, dynamic>> _awards = [];

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    _month = DateTime(now.year, now.month - 1, 1); // last month by default
    _load();
  }

  @override
  void dispose() {
    _days.dispose();
    _pct.dispose();
    _creditDay.dispose();
    super.dispose();
  }

  List<DateTime> get _months {
    final now = DateTime.now();
    return [for (var i = 0; i < 13; i++) DateTime(now.year, now.month - i, 1)];
  }

  DateTime get _defaultCredit {
    final day = int.tryParse(_creditDay.text.trim()) ?? 7;
    return DateTime(_month.year, _month.month + 1, day.clamp(1, 28));
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final st = await supabase.from('incentive_settings').select().eq('id', 1).maybeSingle();
      if (st != null) {
        _enabled = st['enabled'] == true;
        _base = '${st['base'] ?? 'gross'}';
        _days.text = '${st['min_login_days'] ?? 20}';
        _pct.text = '${numOf(st['pct'])}';
        _creditDay.text = '${st['credit_day'] ?? 7}';
      }
      await _loadAwards();
    } catch (e) {
      _error = _err(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _loadAwards() async {
    final r = await supabase
        .from('incentive_awards')
        .select()
        .eq('month', dkey(_month))
        .order('amount', ascending: false);
    _awards = List<Map<String, dynamic>>.from(r);
    final withDate = _awards.where((a) => a['credit_on'] != null).toList();
    _creditOn = withDate.isEmpty ? null : DateTime.tryParse('${withDate.first['credit_on']}');
  }

  Future<void> _saveRules() async {
    final days = int.tryParse(_days.text.trim());
    final pct = num.tryParse(_pct.text.trim());
    final cd = int.tryParse(_creditDay.text.trim());
    if (days == null || days < 1 || days > 31) {
      toast(context, 'Login days must be 1 to 31', error: true);
      return;
    }
    if (pct == null || pct < 0 || pct > 100) {
      toast(context, 'Percentage must be 0 to 100', error: true);
      return;
    }
    if (cd == null || cd < 1 || cd > 28) {
      toast(context, 'Credit day must be 1 to 28', error: true);
      return;
    }
    setState(() => _busy = true);
    String? err;
    try {
      await supabase.from('incentive_settings').update({
        'enabled': _enabled,
        'min_login_days': days,
        'pct': pct,
        'base': _base,
        'credit_day': cd,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      }).eq('id', 1);
    } catch (e) {
      err = _err(e);
    }
    if (mounted) setState(() => _busy = false);
    if (mounted) report(context, err, 'Incentive rules saved');
  }

  Future<void> _pickCreditDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _creditOn ?? _defaultCredit,
      firstDate: DateTime(2024),
      lastDate: DateTime(2100),
      helpText: 'Date the incentive is paid',
    );
    if (d != null) setState(() => _creditOn = d);
  }

  Future<void> _calculate() async {
    setState(() => _busy = true);
    String? err;
    try {
      await supabase.rpc('admin_incentive_calc', params: {
        'p_month': dkey(_month),
        'p_credit_on': dkey(_creditOn ?? _defaultCredit),
      });
      await _loadAwards();
    } catch (e) {
      err = _err(e);
    }
    if (mounted) setState(() => _busy = false);
    if (mounted) report(context, err, 'Calculated for ${_monthLabel(_month)}');
  }

  Future<void> _credit({String? tech}) async {
    final list = _awards.where((a) => a['status'] == 'eligible' && numOf(a['amount']) > 0).toList();
    final who = tech == null ? list : list.where((a) => '${a['technician_id']}' == tech).toList();
    if (who.isEmpty) {
      toast(context, 'Nobody is eligible to credit', error: true);
      return;
    }
    final total = who.fold<num>(0, (a, e) => a + numOf(e['amount']));
    final ok = await confirmBox(
        context,
        'Credit ${money(total)} to ${who.length} technician${who.length == 1 ? '' : 's'} for ${_monthLabel(_month)}? '
        'It is added to their Payments with the pay date ${fday(dkey(_creditOn ?? _defaultCredit))}.',
        yes: 'Credit');
    if (!ok) return;
    setState(() => _busy = true);
    String? err;
    try {
      await supabase.rpc('admin_incentive_credit', params: {'p_month': dkey(_month), 'p_tech': tech});
      await _loadAwards();
      _s.logAction('Credited incentive', _monthLabel(_month));
    } catch (e) {
      err = _err(e);
    }
    if (mounted) setState(() => _busy = false);
    if (mounted) report(context, err, 'Incentive credited');
  }

  Future<void> _hold(Map<String, dynamic> a, bool hold) async {
    String note = '';
    if (hold) {
      final c = TextEditingController();
      final go = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Hold this incentive?'),
          content: TextField(
              controller: c,
              decoration: const InputDecoration(labelText: 'Reason (optional)', border: OutlineInputBorder())),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Hold')),
          ],
        ),
      );
      note = c.text.trim();
      c.dispose();
      if (go != true) return;
    }
    String? err;
    try {
      await supabase.rpc('admin_incentive_hold', params: {'p_id': a['id'], 'p_hold': hold, 'p_note': note});
      await _loadAwards();
    } catch (e) {
      err = _err(e);
    }
    if (mounted) setState(() {});
    if (mounted) report(context, err, hold ? 'Held' : 'Released');
  }

  Widget _status(Map<String, dynamic> a) {
    switch ('${a['status']}') {
      case 'credited':
        return Pill('Credited', kOk);
      case 'eligible':
        return Pill('Eligible', Colors.teal);
      case 'held':
        return Pill('Held', kWarn);
      default:
        return Pill('Not eligible', kBad);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    final minDays = int.tryParse(_days.text.trim()) ?? 0;
    final eligible = _awards.where((a) => a['status'] == 'eligible').toList();
    final credited = _awards.where((a) => a['status'] == 'credited').toList();
    final notEl = _awards.where((a) => a['status'] == 'not_eligible' || a['status'] == 'held').toList();
    num sum(List<Map<String, dynamic>> l) => l.fold<num>(0, (a, e) => a + numOf(e['amount']));
    final pay = _creditOn ?? _defaultCredit;

    return ListView(padding: const EdgeInsets.all(16), children: [
      if (_error != null)
        NoticeBanner('Run the incentive SQL (parts 31 and 32) in Supabase to turn this page on. ($_error)'),
      SectionCard(
        title: 'Incentive rules',
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Incentive is on'),
            subtitle: const Text('Technicians see their incentive in Payments once you calculate and credit it.'),
            value: _enabled,
            onChanged: (v) => setState(() => _enabled = v),
          ),
          const SizedBox(height: 8),
          Wrap(spacing: 12, runSpacing: 12, children: [
            SizedBox(
              width: 200,
              child: TextField(
                controller: _days,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                    labelText: 'Login days needed in a month',
                    helperText: 'Technician must open the app on this many days',
                    border: OutlineInputBorder()),
              ),
            ),
            SizedBox(
              width: 200,
              child: TextField(
                controller: _pct,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                    labelText: 'Incentive % on bookings',
                    helperText: 'On every completed booking',
                    border: OutlineInputBorder()),
              ),
            ),
            SizedBox(
              width: 220,
              child: DropdownButtonFormField<String>(
                value: _base,
                decoration: const InputDecoration(labelText: 'Percentage of', border: OutlineInputBorder()),
                items: const [
                  DropdownMenuItem(value: 'gross', child: Text('Job total paid by customer')),
                  DropdownMenuItem(value: 'earnings', child: Text('Technician earnings (after commission)')),
                ],
                onChanged: (v) => setState(() => _base = v ?? 'gross'),
              ),
            ),
            SizedBox(
              width: 200,
              child: TextField(
                controller: _creditDay,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                    labelText: 'Usual pay day of next month',
                    helperText: '1 to 28. You can change it per month below.',
                    border: OutlineInputBorder()),
              ),
            ),
          ]),
          const SizedBox(height: 12),
          FilledButton(onPressed: _busy ? null : _saveRules, child: const Text('Save rules')),
          const SizedBox(height: 10),
          const Muted('Not eligible: a technician who cancels any booking in the month, logs in fewer days than set, '
              'or has no completed bookings. Cancelled bookings never count in the amount. '
              'Login days are counted from the day the app update went live.'),
        ]),
      ),
      const SectionTitle('Choose a month'),
      Card(
        margin: EdgeInsets.zero,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Wrap(spacing: 12, runSpacing: 12, crossAxisAlignment: WrapCrossAlignment.center, children: [
            DropdownButton<DateTime>(
              value: _months.firstWhere((m) => m == _month, orElse: () => _months[1]),
              items: [for (final m in _months) DropdownMenuItem(value: m, child: Text(_monthLabel(m)))],
              onChanged: _busy
                  ? null
                  : (v) async {
                      if (v == null) return;
                      setState(() {
                        _month = _firstOf(v);
                        _creditOn = null;
                      });
                      try {
                        await _loadAwards();
                      } catch (_) {}
                      if (mounted) setState(() {});
                    },
            ),
            OutlinedButton.icon(
              onPressed: _busy ? null : _pickCreditDate,
              icon: const Icon(Icons.event, size: 18),
              label: Text('Pay date: ${fday(dkey(pay))}'),
            ),
            FilledButton.icon(
              onPressed: _busy ? null : _calculate,
              icon: const Icon(Icons.calculate, size: 18),
              label: const Text('Calculate who is eligible'),
            ),
            FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: kOk),
              onPressed: _busy || eligible.isEmpty ? null : () => _credit(),
              icon: const Icon(Icons.payments, size: 18),
              label: Text('Credit ${eligible.length} eligible (${money(sum(eligible))})'),
            ),
          ]),
        ),
      ),
      const SizedBox(height: 12),
      TileGrid([
        StatTile('Eligible', '${eligible.length}', sub: money(sum(eligible))),
        StatTile('Credited', '${credited.length}', sub: money(sum(credited))),
        StatTile('Not eligible / held', '${notEl.length}'),
        StatTile('Rule', '$minDays days', sub: '${_pct.text}% ${_base == 'gross' ? 'of job total' : 'of earnings'}'),
      ]),
      SectionTitle('${_monthLabel(_month)} - technicians'),
      AdminTable(
        columns: const ['Technician', 'Login days', 'Jobs', 'Job amount', 'Incentive', 'Status', ''],
        numeric: const {1, 2, 3, 4},
        empty: 'Nothing calculated for this month yet. Tap "Calculate who is eligible".',
        rows: [
          for (final a in _awards)
            [
              TwoLine(_s.nameOf(a['technician_id']), '${_s.P['${a['technician_id']}']?['phone'] ?? ''}'),
              Text('${a['login_days']} / $minDays',
                  style: TextStyle(color: numOf(a['login_days']) >= minDays ? kOk : kBad, fontWeight: FontWeight.w600)),
              Text('${a['jobs']}'),
              Text(money(a['base_amount'])),
              Text(money(a['amount']), style: const TextStyle(fontWeight: FontWeight.bold)),
              Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                _status(a),
                if ((a['reason'] ?? '').toString().isNotEmpty) Muted('${a['reason']}'),
                if (a['status'] == 'credited') Muted('Pay date ${fday(a['credit_on'])}'),
              ]),
              Row(mainAxisSize: MainAxisSize.min, children: [
                if (a['status'] == 'eligible') ...[
                  TextButton(onPressed: _busy ? null : () => _credit(tech: '${a['technician_id']}'), child: const Text('Credit')),
                  TextButton(onPressed: _busy ? null : () => _hold(a, true), child: const Text('Hold')),
                ],
                if (a['status'] == 'held')
                  TextButton(onPressed: _busy ? null : () => _hold(a, false), child: const Text('Release')),
              ]),
            ],
        ],
      ),
    ]);
  }
}

// ================================================================== OFFERS

class OffersPage extends StatefulWidget {
  const OffersPage({super.key});
  @override
  State<OffersPage> createState() => _OffersPageState();
}

class _OffersPageState extends State<OffersPage> {
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _offers = [];
  final Map<String, int> _used = {};
  final Map<String, num> _given = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = _offers.isEmpty;
      _error = null;
    });
    try {
      final o = await supabase.from('offers').select().order('created_at', ascending: false);
      _offers = List<Map<String, dynamic>>.from(o);
      _used.clear();
      _given.clear();
      final r = await supabase.from('offer_redemptions').select('offer_id, discount');
      for (final x in r) {
        final id = '${x['offer_id']}';
        _used[id] = (_used[id] ?? 0) + 1;
        _given[id] = (_given[id] ?? 0) + numOf(x['discount']);
      }
    } catch (e) {
      _error = _err(e);
    }
    if (mounted) setState(() => _loading = false);
  }

  String _discountText(Map<String, dynamic> o) {
    final v = numOf(o['value']);
    final vs = v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toString();
    if (o['discount_type'] == 'percent') {
      final m = o['max_discount'];
      return '$vs% off${m != null ? ' (max ${money(m)})' : ''}';
    }
    return '₹$vs off';
  }

  String _state(Map<String, dynamic> o) {
    if (o['active'] != true) return 'Off';
    final today = dkey(DateTime.now());
    if ('${o['date_from']}'.compareTo(today) > 0) return 'Scheduled';
    if ('${o['date_to']}'.compareTo(today) < 0) return 'Expired';
    final lim = o['total_limit'];
    if (lim != null && (_used['${o['id']}'] ?? 0) >= numOf(lim)) return 'Fully used';
    return 'Live';
  }

  Color _stateColor(String s) => s == 'Live' ? kOk : (s == 'Scheduled' ? Colors.blue : (s == 'Off' ? Colors.grey : kWarn));

  Future<void> _edit([Map<String, dynamic>? o]) async {
    final saved = await showDialog<bool>(context: context, builder: (_) => _OfferDialog(offer: o));
    if (saved == true) {
      _s.logAction(o == null ? 'Created offer' : 'Edited offer', '${o?['code'] ?? ''}');
      await _load();
    }
  }

  Future<void> _toggle(Map<String, dynamic> o) async {
    String? err;
    try {
      await supabase.from('offers').update({'active': o['active'] != true}).eq('id', o['id']);
      await _load();
    } catch (e) {
      err = _err(e);
    }
    if (mounted) report(context, err, o['active'] == true ? 'Offer switched off' : 'Offer switched on');
  }

  Future<void> _delete(Map<String, dynamic> o) async {
    final used = _used['${o['id']}'] ?? 0;
    final ok = await confirmBox(
        context,
        used > 0
            ? 'This offer was used $used time(s). Deleting removes its history. Switch it off instead? Tap Delete only if you are sure.'
            : 'Delete offer ${o['code']}?',
        yes: 'Delete');
    if (!ok) return;
    String? err;
    try {
      await supabase.from('offers').delete().eq('id', o['id']);
      await _load();
    } catch (e) {
      err = _err(e);
    }
    if (mounted) report(context, err, 'Offer deleted');
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    final live = _offers.where((o) => _state(o) == 'Live').length;
    final totalUsed = _used.values.fold<int>(0, (a, b) => a + b);
    final totalGiven = _given.values.fold<num>(0, (a, b) => a + b);
    return ListView(padding: const EdgeInsets.all(16), children: [
      if (_error != null)
        NoticeBanner('Run the offers SQL (parts 33, 33b and 34) in Supabase to turn this page on. ($_error)'),
      Row(children: [
        const Expanded(
            child: Text('Customers type the code, or pick an offer, when they pay for a booking.',
                style: TextStyle(color: Colors.black54))),
        FilledButton.icon(onPressed: () => _edit(), icon: const Icon(Icons.add), label: const Text('New offer')),
      ]),
      const SizedBox(height: 12),
      TileGrid([
        StatTile('Live offers', '$live'),
        StatTile('Times used', '$totalUsed'),
        StatTile('Discount given', money(totalGiven), sub: 'Paid by Fixeaze, not technicians'),
      ]),
      const SectionTitle('All offers'),
      AdminTable(
        columns: const ['Code', 'Offer', 'Rules', 'Valid', 'Used', 'Status', ''],
        numeric: const {4},
        empty: 'No offers yet. Tap "New offer".',
        rows: [
          for (final o in _offers)
            [
              Text('${o['code']}', style: const TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
              TwoLine('${o['title']}', _discountText(o)),
              Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Muted(numOf(o['min_order']) > 0 ? 'Min order ${money(o['min_order'])}' : 'No minimum'),
                Muted('${o['per_customer']} use(s) per customer${o['first_booking_only'] == true ? ', first booking only' : ''}'),
              ]),
              Text('${fday(o['date_from'])} to\n${fday(o['date_to'])}', style: const TextStyle(fontSize: 12)),
              Text('${_used['${o['id']}'] ?? 0}${o['total_limit'] != null ? ' / ${o['total_limit']}' : ''}'),
              Pill(_state(o), _stateColor(_state(o))),
              Row(mainAxisSize: MainAxisSize.min, children: [
                TextButton(onPressed: () => _edit(o), child: const Text('Edit')),
                TextButton(onPressed: () => _toggle(o), child: Text(o['active'] == true ? 'Switch off' : 'Switch on')),
                IconButton(
                    tooltip: 'Delete',
                    onPressed: () => _delete(o),
                    icon: const Icon(Icons.delete_outline, color: kBad, size: 20)),
              ]),
            ],
        ],
      ),
    ]);
  }
}

class _OfferDialog extends StatefulWidget {
  final Map<String, dynamic>? offer;
  const _OfferDialog({this.offer});
  @override
  State<_OfferDialog> createState() => _OfferDialogState();
}

class _OfferDialogState extends State<_OfferDialog> {
  final _code = TextEditingController();
  final _title = TextEditingController();
  final _value = TextEditingController();
  final _max = TextEditingController();
  final _min = TextEditingController();
  final _limit = TextEditingController();
  final _per = TextEditingController(text: '1');
  String _type = 'percent';
  DateTime _from = DateTime.now();
  DateTime _to = DateTime.now().add(const Duration(days: 30));
  bool _first = false;
  bool _active = true;
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    final o = widget.offer;
    if (o != null) {
      _code.text = '${o['code']}';
      _title.text = '${o['title']}';
      _type = '${o['discount_type']}';
      _value.text = '${numOf(o['value'])}';
      _max.text = o['max_discount'] == null ? '' : '${numOf(o['max_discount'])}';
      _min.text = numOf(o['min_order']) > 0 ? '${numOf(o['min_order'])}' : '';
      _limit.text = o['total_limit'] == null ? '' : '${o['total_limit']}';
      _per.text = '${o['per_customer'] ?? 1}';
      _from = DateTime.tryParse('${o['date_from']}') ?? _from;
      _to = DateTime.tryParse('${o['date_to']}') ?? _to;
      _first = o['first_booking_only'] == true;
      _active = o['active'] != false;
    }
  }

  @override
  void dispose() {
    for (final c in [_code, _title, _value, _max, _min, _limit, _per]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _pick(bool from) async {
    final d = await showDatePicker(
      context: context,
      initialDate: from ? _from : _to,
      firstDate: DateTime(2024),
      lastDate: DateTime(2100),
    );
    if (d == null) return;
    setState(() {
      if (from) {
        _from = d;
        if (_to.isBefore(_from)) _to = _from;
      } else {
        _to = d;
      }
    });
  }

  Future<void> _save() async {
    final code = _code.text.trim().toUpperCase().replaceAll(' ', '');
    final value = num.tryParse(_value.text.trim());
    if (code.length < 3) {
      setState(() => _error = 'Code needs at least 3 letters or numbers');
      return;
    }
    if (_title.text.trim().isEmpty) {
      setState(() => _error = 'Add a short title customers will see');
      return;
    }
    if (value == null || value <= 0) {
      setState(() => _error = 'Enter the discount amount');
      return;
    }
    if (_type == 'percent' && value > 100) {
      setState(() => _error = 'Percent cannot be more than 100');
      return;
    }
    if (_to.isBefore(_from)) {
      setState(() => _error = 'End date is before the start date');
      return;
    }
    final per = int.tryParse(_per.text.trim()) ?? 1;
    if (per < 1) {
      setState(() => _error = 'Uses per customer must be at least 1');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final row = {
      'code': code,
      'title': _title.text.trim(),
      'discount_type': _type,
      'value': value,
      'max_discount': _type == 'percent' ? num.tryParse(_max.text.trim()) : null,
      'min_order': num.tryParse(_min.text.trim()) ?? 0,
      'date_from': dkey(_from),
      'date_to': dkey(_to),
      'total_limit': int.tryParse(_limit.text.trim()),
      'per_customer': per,
      'first_booking_only': _first,
      'active': _active,
    };
    try {
      if (widget.offer == null) {
        await supabase.from('offers').insert(row);
      } else {
        await supabase.from('offers').update(row).eq('id', widget.offer!['id']);
      }
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      final m = _err(e);
      if (mounted) {
        setState(() {
          _busy = false;
          _error = m.contains('offers_code_key') || m.contains('duplicate') ? 'This code already exists' : m;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.offer == null ? 'New offer' : 'Edit offer'),
      content: SizedBox(
        width: 420,
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            TextField(
                controller: _code,
                textCapitalization: TextCapitalization.characters,
                decoration: const InputDecoration(
                    labelText: 'Offer code', helperText: 'What the customer types, e.g. WELCOME100', border: OutlineInputBorder())),
            const SizedBox(height: 12),
            TextField(
                controller: _title,
                decoration: const InputDecoration(labelText: 'Title shown to customers', border: OutlineInputBorder())),
            const SizedBox(height: 12),
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'percent', label: Text('Percent off')),
                ButtonSegment(value: 'flat', label: Text('Rupees off')),
              ],
              selected: {_type},
              onSelectionChanged: (v) => setState(() => _type = v.first),
            ),
            const SizedBox(height: 12),
            TextField(
                controller: _value,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(
                    labelText: _type == 'percent' ? 'Percent (e.g. 10)' : 'Amount in rupees (e.g. 100)',
                    border: const OutlineInputBorder())),
            if (_type == 'percent') ...[
              const SizedBox(height: 12),
              TextField(
                  controller: _max,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                      labelText: 'Maximum discount in rupees (optional)', border: OutlineInputBorder())),
            ],
            const SizedBox(height: 12),
            TextField(
                controller: _min,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                    labelText: 'Minimum bill in rupees (optional)', border: OutlineInputBorder())),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                  child: OutlinedButton(onPressed: () => _pick(true), child: Text('From ${fday(dkey(_from))}'))),
              const SizedBox(width: 8),
              Expanded(child: OutlinedButton(onPressed: () => _pick(false), child: Text('To ${fday(dkey(_to))}'))),
            ]),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                  child: TextField(
                      controller: _per,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Uses per customer', border: OutlineInputBorder()))),
              const SizedBox(width: 8),
              Expanded(
                  child: TextField(
                      controller: _limit,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                          labelText: 'Total uses (blank = no limit)', border: OutlineInputBorder()))),
            ]),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('First booking only'),
              subtitle: const Text('Only customers with no completed booking'),
              value: _first,
              onChanged: (v) => setState(() => _first = v),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Active'),
              value: _active,
              onChanged: (v) => setState(() => _active = v),
            ),
            if (_error != null) Text(_error!, style: const TextStyle(color: kBad)),
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: _busy ? null : () => Navigator.pop(context, false), child: const Text('Cancel')),
        FilledButton(onPressed: _busy ? null : _save, child: const Text('Save')),
      ],
    );
  }
}
