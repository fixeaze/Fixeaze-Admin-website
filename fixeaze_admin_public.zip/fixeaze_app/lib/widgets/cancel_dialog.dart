import 'package:flutter/material.dart';

const customerCancelReasons = [
  'Changed my plan',
  'Booked by mistake',
  'Found another technician',
  'Technician is taking too long',
  'Price is too high',
  'Wrong address or time',
  'Other',
];
const technicianCancelReasons = [
  'Skill set issue',
  'Personal emergency',
  'Customer location too far',
  'Vehicle or tools problem',
  'Customer not reachable',
  'Health issue',
  'Other',
];

class CancelResult {
  final String reason, note;
  const CancelResult(this.reason, this.note);
}

const technicianDeclineReasons = [
  'Too busy right now',
  'Customer location too far',
  'Skill set issue',
  'Price is too low',
  'Time does not suit me',
  'Personal emergency',
  'Other',
];

Future<CancelResult?> showCancelDialog(
  BuildContext context, {
  required bool technician,
  bool decline = false,
}) {
  final reasons = decline ? technicianDeclineReasons : (technician ? technicianCancelReasons : customerCancelReasons);
  String? reason;
  final note = TextEditingController();
  return showDialog<CancelResult>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setLocal) => AlertDialog(
        title: Text(decline ? 'Decline this job?' : (technician ? 'Cancel this job?' : 'Cancel this booking?')),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(
              decline
                  ? 'The job stays open for other technicians. Please tell us why you do not want it.'
                  : technician
                  ? 'The job goes back to other technicians. Frequent cancellations can affect your rating or account.'
                  : 'The technician will no longer be able to take this job.',
              style: const TextStyle(color: Colors.black54, fontSize: 13),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: reason,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'Reason', border: OutlineInputBorder()),
              items: [for (final r in reasons) DropdownMenuItem(value: r, child: Text(r))],
              onChanged: (v) => setLocal(() => reason = v),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: note,
              maxLines: 3,
              decoration: InputDecoration(
                labelText: reason == 'Other' ? 'Please explain (required)' : 'More details (optional)',
                border: const OutlineInputBorder(),
              ),
              onChanged: (_) => setLocal(() {}),
            ),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(decline ? 'Go back' : 'Keep it')),
          FilledButton(
            onPressed: reason == null || (reason == 'Other' && note.text.trim().isEmpty)
                ? null
                : () => Navigator.pop(ctx, CancelResult(reason!, note.text.trim())),
            child: Text(decline ? 'Decline job' : (technician ? 'Cancel job' : 'Cancel booking')),
          ),
        ],
      ),
    ),
  );
}
