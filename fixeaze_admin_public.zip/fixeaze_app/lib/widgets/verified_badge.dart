import 'package:flutter/material.dart';

import '../config.dart';

const _gold = Color(0xFFF2B01E);
const _goldDark = Color(0xFFC98A00);
const _silver = Color(0xFF9AA5B1);
const _silverDark = Color(0xFF6B7683);
const _green = Color(0xFF1F6B45);

/// Gold or silver scalloped tick with a green check, like a verified badge.
/// [tier] is 'gold', 'silver' or null (shows nothing).
class VerifiedBadge extends StatelessWidget {
  final String? tier;
  final double size;
  const VerifiedBadge(this.tier, {super.key, this.size = 18});

  static Color colorOf(String? t) => t == 'gold' ? _gold : _silver;

  @override
  Widget build(BuildContext context) {
    if (tier != 'gold' && tier != 'silver') return const SizedBox.shrink();
    final gold = tier == 'gold';
    return Tooltip(
      message: gold ? 'Gold verified technician' : 'Silver verified technician',
      child: SizedBox(
        width: size,
        height: size,
        child: Stack(alignment: Alignment.center, children: [
          Icon(Icons.verified, size: size, color: gold ? _gold : _silver),
          Icon(Icons.check, size: size * 0.52, color: gold ? _green : Colors.white),
        ]),
      ),
    );
  }
}

/// Name followed by the badge. Tapping the badge explains it.
class NameWithBadge extends StatelessWidget {
  final String name;
  final String? tier;
  final TextStyle? style;
  const NameWithBadge(this.name, this.tier, {super.key, this.style});

  @override
  Widget build(BuildContext context) {
    return Row(mainAxisSize: MainAxisSize.min, children: [
      Flexible(child: Text(name, style: style, overflow: TextOverflow.ellipsis)),
      if (tier == 'gold' || tier == 'silver') ...[
        const SizedBox(width: 4),
        GestureDetector(onTap: () => showBadgeInfo(context, tier), child: VerifiedBadge(tier, size: 18)),
      ],
    ]);
  }
}

/// Small text for customers: why the technician is verified.
void showBadgeInfo(BuildContext context, String? tier) {
  final gold = tier == 'gold';
  showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      icon: VerifiedBadge(tier, size: 44),
      title: Text(gold ? 'Gold verified technician' : 'Silver verified technician'),
      content: Text(
          gold
              ? 'This technician has an average customer rating of 4 or more. '
                  'The badge is given automatically by Fixeaze from real customer ratings, and it is removed if the rating falls.'
              : 'This technician has an average customer rating between 3 and 4. '
                  'The badge is given automatically by Fixeaze from real customer ratings. A Gold badge means 4 or more.',
          style: const TextStyle(height: 1.4)),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Got it'))],
    ),
  );
}

/// Technician: where am I, what do I need, how do I keep it.
class BadgeProgressCard extends StatefulWidget {
  const BadgeProgressCard({super.key});
  @override
  State<BadgeProgressCard> createState() => _BadgeProgressCardState();
}

class _BadgeProgressCardState extends State<BadgeProgressCard> {
  Map<String, dynamic>? _d;
  bool _open = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await supabase.rpc('my_badge_status');
      if (r is Map && mounted) setState(() => _d = Map<String, dynamic>.from(r));
    } catch (_) {
      // part 49 not run yet: show nothing
    }
  }

  num _n(String k) => num.tryParse('${_d?[k] ?? 0}') ?? 0;

  @override
  Widget build(BuildContext context) {
    final d = _d;
    if (d == null) return const SizedBox.shrink();
    final badge = d['badge'] as String?;
    final rating = _n('rating').toDouble();
    final count = _n('rating_count').toInt();
    final need = _n('min_ratings').toInt();
    final goldAt = _n('gold_min_rating').toDouble();
    final silverAt = _n('silver_min_rating').toDouble();
    final enabled = d['enabled'] == true;

    final color = badge == 'gold' ? _goldDark : (badge == 'silver' ? _silverDark : Colors.blueGrey);
    String head;
    String sub;
    double progress;
    if (count < need) {
      head = 'Earn your badge';
      sub = '$count of $need customer ratings. After $need ratings you get Silver (rating $silverAt+) or Gold (rating $goldAt+).';
      progress = need == 0 ? 0 : count / need;
    } else if (badge == 'gold') {
      head = 'You are a Gold technician';
      sub = 'Rating ${rating.toStringAsFixed(2)}. Keep it at $goldAt or more to stay Gold.';
      progress = 1;
    } else if (badge == 'silver') {
      head = 'You are a Silver technician';
      final gap = (goldAt - rating).clamp(0, 5);
      sub = 'Rating ${rating.toStringAsFixed(2)}. ${gap.toStringAsFixed(2)} more to reach Gold ($goldAt).';
      progress = ((rating - silverAt) / (goldAt - silverAt)).clamp(0.0, 1.0);
    } else {
      head = 'No badge yet';
      sub = 'Rating ${rating.toStringAsFixed(2)}. You need $silverAt or more for Silver.';
      progress = (rating / silverAt).clamp(0.0, 1.0);
    }

    final jobs = _n('jobs').toInt();
    final days = _n('login_days').toInt();
    final needJobs = d['min_jobs'] == null ? null : _n('min_jobs').toInt();
    final needDays = d['min_login_days'] == null ? null : _n('min_login_days').toInt();

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16), side: BorderSide(color: color.withOpacity(0.5), width: 1.4)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            badge == null ? Icon(Icons.verified_outlined, color: color, size: 30) : VerifiedBadge(badge, size: 30),
            const SizedBox(width: 10),
            Expanded(child: Text(head, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: color))),
            IconButton(
              visualDensity: VisualDensity.compact,
              icon: Icon(_open ? Icons.expand_less : Icons.expand_more),
              onPressed: () => setState(() => _open = !_open),
            ),
          ]),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(value: progress, minHeight: 8, color: color, backgroundColor: color.withOpacity(0.15)),
          ),
          const SizedBox(height: 8),
          Text(sub, style: const TextStyle(height: 1.35)),
          if (enabled && badge != null && needJobs != null && needDays != null) ...[
            const Divider(height: 22),
            Text('This month\'s incentive (${d['pct']}% on every booking)',
                style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            _line(Icons.work, 'Completed bookings', jobs, needJobs),
            _line(Icons.login, 'Days you opened the app', days, needDays),
          ],
          if (enabled && badge == null && count >= need) ...[
            const Divider(height: 22),
            const Text('Incentive starts once you have a Silver or Gold badge.', style: TextStyle(height: 1.35)),
          ],
          if (_open) ...[
            const Divider(height: 22),
            const Text('How it works', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text(
                'Your badge comes from your customers\' average rating, automatically. '
                'Silver = $silverAt to below $goldAt. Gold = $goldAt or more. '
                'If your rating goes down the badge goes away, and it comes back when the rating is back up.\n\n'
                'To keep it: be on time, finish the job properly, talk politely, share photos and keep the customer informed. '
                'Do not cancel accepted bookings, because a cancelled booking in a month means no incentive for that month.',
                style: const TextStyle(height: 1.4)),
          ],
        ]),
      ),
    );
  }

  Widget _line(IconData icon, String label, int have, int need) {
    final ok = have >= need;
    return Padding(
      padding: const EdgeInsets.only(top: 4),
      child: Row(children: [
        Icon(icon, size: 16, color: Colors.black45),
        const SizedBox(width: 6),
        Expanded(child: Text(label)),
        Text('$have / $need',
            style: TextStyle(fontWeight: FontWeight.w700, color: ok ? Colors.green.shade700 : Colors.orange.shade800)),
        const SizedBox(width: 4),
        Icon(ok ? Icons.check_circle : Icons.hourglass_bottom, size: 16, color: ok ? Colors.green : Colors.orange),
      ]),
    );
  }
}

/// Technician profile: shows the badge they currently hold (nothing if none).
class MyBadgeChip extends StatelessWidget {
  const MyBadgeChip({super.key});

  Future<String?> _load() async {
    try {
      final r = await supabase
          .from('technician_profiles')
          .select('badge')
          .eq('id', supabase.auth.currentUser!.id)
          .maybeSingle();
      return r?['badge'] as String?;
    } catch (_) {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<String?>(
      future: _load(),
      builder: (context, snap) {
        final t = snap.data;
        if (t == null) return const SizedBox.shrink();
        return Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Center(
            child: GestureDetector(
              onTap: () => showBadgeInfo(context, t),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                    color: VerifiedBadge.colorOf(t).withOpacity(0.18), borderRadius: BorderRadius.circular(20)),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  VerifiedBadge(t, size: 20),
                  const SizedBox(width: 6),
                  Text(t == 'gold' ? 'Gold verified' : 'Silver verified', style: const TextStyle(fontWeight: FontWeight.bold)),
                ]),
              ),
            ),
          ),
        );
      },
    );
  }
}
