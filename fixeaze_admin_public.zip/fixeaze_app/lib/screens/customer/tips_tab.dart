import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../dark_mode.dart';

import '../../config.dart';
import '../../theme.dart';
import '../../widgets/common.dart';
import '../../widgets/fun_loader.dart';

const _tipTints = [Color(0xFFE7EFE9), Color(0xFFF6E9D7), Color(0xFFE3ECF3), Color(0xFFF1E4E4)];

/// Care tips: small product cards. Tap one to read its daily and monthly tips.
class TipsTab extends StatefulWidget {
  const TipsTab({super.key});

  @override
  State<TipsTab> createState() => _TipsTabState();
}

class _TipsTabState extends State<TipsTab> {
  late Future<List<Map<String, dynamic>>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async {
    final rows = await supabase
        .from('tip_products')
        .select()
        .eq('active', true)
        .order('sort')
        .order('name');
    return List<Map<String, dynamic>>.from(rows);
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) return const FunLoader();
        if (snap.hasError) {
          return ErrorState(error: snap.error!, onRetry: () => setState(() => _future = _load()));
        }
        final products = snap.data!;
        return RefreshIndicator(
          onRefresh: () async {
            setState(() => _future = _load());
            await _future;
          },
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text('Care tips', style: GoogleFonts.dmSerifDisplay(fontSize: 28, color: kInk)),
              const SizedBox(height: 4),
              const Text('Choose a product to see simple daily and monthly habits that keep it running longer.',
                  style: TextStyle(color: Colors.black54)),
              const SizedBox(height: 16),
              if (products.isEmpty)
                const EmptyState(icon: Icons.lightbulb_outline, text: 'No tips yet.')
              else
                GridView.count(
                  crossAxisCount: 3,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  childAspectRatio: 0.95,
                  children: [
                    for (var i = 0; i < products.length; i++)
                      _TipProductTile(
                        product: products[i],
                        tint: _tipTints[i % _tipTints.length],
                      ),
                  ],
                ),
            ],
          ),
        );
      },
    );
  }
}

class _TipProductTile extends StatelessWidget {
  final Map<String, dynamic> product;
  final Color tint;
  const _TipProductTile({required this.product, required this.tint});

  @override
  Widget build(BuildContext context) {
    final name = '${product['name']}';
    final url = product['image_url'] as String?;
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => TipProductPage(product: product, tint: tint)),
      ),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
        decoration: BoxDecoration(color: tint, borderRadius: BorderRadius.circular(16)),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          DarkSafe(child: CircleAvatar(
            radius: 22,
            backgroundColor: Colors.white,
            backgroundImage: (url != null && url.isNotEmpty) ? NetworkImage(url) : null,
            child: (url == null || url.isEmpty) ? Icon(serviceIcon(name), color: kTeal, size: 22) : null,
          )),
          const SizedBox(height: 7),
          Text(name,
              maxLines: 2,
              textAlign: TextAlign.center,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5, height: 1.15, color: kInk)),
        ]),
      ),
    );
  }
}

/// Daily and monthly tips for one product.
class TipProductPage extends StatefulWidget {
  final Map<String, dynamic> product;
  final Color tint;
  const TipProductPage({super.key, required this.product, required this.tint});

  @override
  State<TipProductPage> createState() => _TipProductPageState();
}

class _TipProductPageState extends State<TipProductPage> {
  late Future<List<Map<String, dynamic>>> _future;
  String _frequency = 'daily';

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async {
    final rows = await supabase
        .from('maintenance_tips')
        .select()
        .eq('tip_product_id', widget.product['id'])
        .eq('active', true)
        .order('sort')
        .order('title');
    return List<Map<String, dynamic>>.from(rows);
  }

  @override
  Widget build(BuildContext context) {
    final name = '${widget.product['name']}';
    return Scaffold(
      backgroundColor: kCream,
      appBar: AppBar(title: Text(name)),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) return const FunLoader();
          if (snap.hasError) {
            return ErrorState(error: snap.error!, onRetry: () => setState(() => _future = _load()));
          }
          final tips = snap.data!.where((t) => t['frequency'] == _frequency).toList();
          final now = DateTime.now();
          final dayOfYear = now.difference(DateTime(now.year, 1, 1)).inDays;
          final featured = tips.isEmpty ? null : tips[(_frequency == 'daily' ? dayOfYear : now.month) % tips.length];
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: 'daily', icon: Icon(Icons.today), label: Text('Daily')),
                  ButtonSegment(value: 'monthly', icon: Icon(Icons.calendar_month), label: Text('Monthly')),
                ],
                selected: {_frequency},
                onSelectionChanged: (s) => setState(() => _frequency = s.first),
              ),
              const SizedBox(height: 16),
              if (featured != null)
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(color: kTeal, borderRadius: BorderRadius.circular(22)),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(_frequency == 'daily' ? 'TIP OF THE DAY' : 'TIP OF THE MONTH',
                        style: const TextStyle(color: kAmber, fontSize: 12, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 6),
                    Text('${featured['title']}',
                        style: GoogleFonts.dmSerifDisplay(color: Colors.white, fontSize: 22, height: 1.1)),
                    const SizedBox(height: 6),
                    Text('${featured['body'] ?? ''}', style: const TextStyle(color: Colors.white, height: 1.35)),
                  ]),
                ),
              const SizedBox(height: 16),
              if (tips.isEmpty)
                EmptyState(
                    icon: Icons.lightbulb_outline,
                    text: 'No ${_frequency == 'daily' ? 'daily' : 'monthly'} tips for $name yet.')
              else
                for (final t in tips)
                  Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: kLine),
                    ),
                    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      CircleAvatar(
                          radius: 18,
                          backgroundColor: widget.tint,
                          child: Icon(_frequency == 'daily' ? Icons.today : Icons.calendar_month, color: kTeal, size: 18)),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('${t['title']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                          const SizedBox(height: 3),
                          Text('${t['body'] ?? ''}', style: const TextStyle(color: Colors.black54, height: 1.35)),
                        ]),
                      ),
                    ]),
                  ),
            ],
          );
        },
      ),
    );
  }
}
