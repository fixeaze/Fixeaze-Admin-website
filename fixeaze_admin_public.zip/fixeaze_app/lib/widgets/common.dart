import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../dark_mode.dart';
import 'package:intl/intl.dart';

void snack(BuildContext context, String message, {bool error = false}) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Text(message),
      backgroundColor: error ? Colors.red.shade700 : null,
    ));
}

String fmtDate(dynamic iso) {
  if (iso == null) return '';
  return DateFormat('EEE, d MMM y • h:mm a')
      .format(DateTime.parse(iso.toString()).toLocal());
}

String money(dynamic value) {
  if (value == null) return '';
  final n = num.tryParse(value.toString()) ?? 0;
  final whole = n == n.roundToDouble();
  return '₹${n.toStringAsFixed(whole ? 0 : 2)}';
}

String bookingTypeLabel(Map<String, dynamic> b) {
  if (b['booking_type'] == 'inspection') return 'Estimate & inspection visit';
  final h = b['hours'];
  return h == null ? 'Hourly booking' : 'Hourly booking • $h hr';
}

IconData serviceIcon(String name) {
  final n = name.toLowerCase();
  if (n.contains('plumb')) return Icons.plumbing;
  if (n.contains('elec')) return Icons.electrical_services;
  if (n.contains('appliance')) return Icons.kitchen;
  if (n.startsWith('ac') || n.contains('air con')) return Icons.ac_unit;
  if (n.contains('clean')) return Icons.cleaning_services;
  if (n.contains('paint')) return Icons.format_paint;
  return Icons.handyman;
}

/// Keeps content readable on wide web screens.
class Constrained extends StatelessWidget {
  final Widget child;
  final double maxWidth;
  const Constrained({super.key, required this.child, this.maxWidth = 900});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: maxWidth),
        child: child,
      ),
    );
  }
}

class StatusChip extends StatelessWidget {
  final String status;
  const StatusChip(this.status, {super.key});

  static const Map<String, String> _labels = {
    'pending': 'Waiting for technician',
    'accepted': 'Technician assigned',
    'in_progress': 'In progress',
    'completed': 'Completed',
    'cancelled': 'Cancelled',
  };

  static const Map<String, Color> _colors = {
    'pending': Colors.orange,
    'accepted': Colors.blue,
    'in_progress': Colors.deepPurple,
    'completed': Colors.green,
    'cancelled': Colors.grey,
  };

  @override
  Widget build(BuildContext context) {
    final color = _colors[status] ?? Colors.grey;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        _labels[status] ?? status,
        style: TextStyle(color: color, fontWeight: FontWeight.w600, fontSize: 12),
      ),
    );
  }
}

class EmptyState extends StatelessWidget {
  final IconData icon;
  final String text;
  const EmptyState({super.key, required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 56, color: Colors.black26),
            const SizedBox(height: 12),
            Text(text, textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.black54, fontSize: 16)),
          ],
        ),
      ),
    );
  }
}

class ErrorState extends StatelessWidget {
  final Object error;
  final VoidCallback onRetry;
  const ErrorState({super.key, required this.error, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, size: 48, color: Colors.redAccent),
            const SizedBox(height: 12),
            Text('Something went wrong.\n$error',
                textAlign: TextAlign.center, maxLines: 5,
                overflow: TextOverflow.ellipsis),
            const SizedBox(height: 16),
            OutlinedButton(onPressed: onRetry, child: const Text('Try again')),
          ],
        ),
      ),
    );
  }
}

/// Row of small photo thumbnails. Tap to enlarge. Pass onRemove to show an X.
class PhotoStrip extends StatelessWidget {
  final List<String> urls;
  final void Function(int index)? onRemove;
  const PhotoStrip({super.key, required this.urls, this.onRemove});

  @override
  Widget build(BuildContext context) {
    if (urls.isEmpty) return const SizedBox.shrink();
    return SizedBox(
      height: 72,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: urls.length,
        separatorBuilder: (context, index) => const SizedBox(width: 8),
        itemBuilder: (context, i) {
          return Stack(
            children: [
              GestureDetector(
                onTap: () => showDialog(
                  context: context,
                  builder: (_) => Dialog(
                    child: InteractiveViewer(child: DarkSafe(child: Image.network(urls[i]))),
                  ),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: DarkSafe(child: Image.network(urls[i],
                      width: 72, height: 72, fit: BoxFit.cover)),
                ),
              ),
              if (onRemove != null)
                Positioned(
                  top: 2,
                  right: 2,
                  child: InkWell(
                    onTap: () => onRemove!(i),
                    child: const CircleAvatar(
                      radius: 10,
                      backgroundColor: Colors.black54,
                      child: Icon(Icons.close, size: 12, color: Colors.white),
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

class AppBarTitle extends StatelessWidget {
  final String subtitle;
  const AppBarTitle({super.key, this.subtitle = ''});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: DarkSafe(child: Image.asset('assets/logo.png', width: 32, height: 32)),
        ),
        const SizedBox(width: 10),
        Text('Fixeaze', style: GoogleFonts.dmSerifDisplay(fontSize: 22)),
        if (subtitle.isNotEmpty) ...[
          const SizedBox(width: 8),
          Text(subtitle, style: const TextStyle(fontSize: 13, color: Colors.black54)),
        ],
      ],
    );
  }
}

/// Dots-and-line progress for one booking, with the step names.
class OrderProgress extends StatelessWidget {
  final Map<String, dynamic> booking;
  const OrderProgress(this.booking, {super.key});

  static const steps = ['Booked', 'Accepted', 'Arrived', 'Working', 'Payment', 'Done'];

  static int stepOf(Map<String, dynamic> b) {
    final status = (b['status'] ?? '').toString();
    final stage = (b['job_stage'] ?? '').toString();
    if (status == 'completed' || stage == 'done') return 5;
    if (status == 'pending') return 0;
    switch (stage) {
      case 'arrived':
        return 2;
      case 'working':
      case 'parts_review':
        return 3;
      case 'payment_due':
      case 'payment_check':
      case 'work_check':
      case 'end_otp':
        return 4;
      default:
        return 1;
    }
  }

  @override
  Widget build(BuildContext context) {
    final status = (booking['status'] ?? '').toString();
    if (status == 'cancelled') {
      return const Padding(
        padding: EdgeInsets.only(top: 6),
        child: Text('Order cancelled', style: TextStyle(color: Colors.red, fontWeight: FontWeight.w600)),
      );
    }
    final cur = stepOf(booking);
    const teal = Color(0xFF1F4D3A);
    final left = steps.length - 1 - cur;
    return Padding(
      padding: const EdgeInsets.only(top: 10, bottom: 4),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          for (var i = 0; i < steps.length; i++) ...[
            Container(
              width: i == cur ? 16 : 12,
              height: i == cur ? 16 : 12,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: i <= cur ? teal : Colors.white,
                border: Border.all(color: i <= cur ? teal : Colors.black26, width: 2),
              ),
              child: i < cur ? const Icon(Icons.check, size: 8, color: Colors.white) : null,
            ),
            if (i < steps.length - 1)
              Expanded(child: Container(height: 3, color: i < cur ? teal : Colors.black12)),
          ],
        ]),
        const SizedBox(height: 6),
        Row(children: [
          for (var i = 0; i < steps.length; i++)
            Expanded(
              child: Text(steps[i],
                  textAlign: i == 0 ? TextAlign.left : (i == steps.length - 1 ? TextAlign.right : TextAlign.center),
                  style: TextStyle(
                      fontSize: 9.5,
                      fontWeight: i == cur ? FontWeight.w800 : FontWeight.w500,
                      color: i == cur ? teal : Colors.black45)),
            ),
        ]),
        const SizedBox(height: 4),
        Text(left == 0 ? 'Step ${cur + 1} of ${steps.length}: complete' : 'Step ${cur + 1} of ${steps.length}  |  $left to go',
            style: const TextStyle(fontSize: 12, color: Colors.black54)),
      ]),
    );
  }
}
