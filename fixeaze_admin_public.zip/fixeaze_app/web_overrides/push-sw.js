// Fixeaze admin notifications (Web Push). Shows the alert even when the app is closed.
self.addEventListener('install', function () { self.skipWaiting(); });
self.addEventListener('activate', function (e) { e.waitUntil(self.clients.claim()); });

self.addEventListener('push', function (event) {
  var d = {};
  try { d = event.data ? event.data.json() : {}; } catch (_) { d = {}; }
  var kind = d.kind || 'alert';
  var isChat = kind === 'chat';
  event.waitUntil((async function () {
    var wins = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    wins.forEach(function (c) { c.postMessage({ type: 'fx-push', kind: kind, title: d.title, body: d.body }); });
    var visible = wins.some(function (c) { return c.visibilityState === 'visible'; });
    if (visible && kind !== 'test') return; // the open app plays its own sound
    await self.registration.showNotification(d.title || 'Fixeaze', {
      body: d.body || '',
      icon: new URL('../icons/Icon-192.png', self.registration.scope).href,
      badge: new URL('../icons/Icon-192.png', self.registration.scope).href,
      tag: isChat ? 'fx-chat' : 'fx-' + kind + '-' + Date.now(),
      renotify: true,
      requireInteraction: kind === 'sos',
      // Closed-app sound is chosen by the phone. Chat gets a short buzz, everything else a long one.
      vibrate: isChat ? [90, 60, 90] : [500, 200, 500, 200, 500],
      data: { kind: kind }
    });
  })());
});

self.addEventListener('notificationclick', function (event) {
  event.notification.close();
  event.waitUntil((async function () {
    var wins = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (var i = 0; i < wins.length; i++) {
      if ('focus' in wins[i]) return wins[i].focus();
    }
    if (self.clients.openWindow) return self.clients.openWindow(new URL('../', self.registration.scope).href);
  })());
});
