import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Dark mode by "smart invert": the whole app is drawn through a colour filter that
/// flips light to dark and keeps every hue (green stays green, red stays red).
/// Photos and logos are drawn through the opposite filter (DarkSafe) so they look normal.

const _h = [
  [-0.574, 1.43, 0.144],
  [0.426, 0.43, 0.144],
  [0.426, 1.43, -0.856],
]; // hue-rotate 180 degrees

List<double> _matrix(double k, double off) => [
      for (final r in _h) ...[-k * r[0], -k * r[1], -k * r[2], 0, off],
      0, 0, 0, 1, 0,
    ];

// Whole app: slightly lifted black, so cards and background stay apart.
final _appFilter = ColorFilter.matrix(_matrix(0.9, 251.5));
// Exact opposite of the one above, for photos and logos.
final _photoFilter = ColorFilter.matrix(_matrix(1 / 0.9, 279.44));

class DarkMode {
  static final ValueNotifier<bool> on = ValueNotifier<bool>(false);

  static Future<void> load() async {
    try {
      final p = await SharedPreferences.getInstance();
      on.value = p.getBool('fx_dark') ?? false;
    } catch (_) {}
  }

  static Future<void> set(bool v) async {
    on.value = v;
    try {
      final p = await SharedPreferences.getInstance();
      await p.setBool('fx_dark', v);
    } catch (_) {}
  }

  static void toggle() => set(!on.value);
}

/// Put around the whole app (MaterialApp.builder).
class DarkModeShell extends StatefulWidget {
  final Widget child;
  const DarkModeShell({super.key, required this.child});
  @override
  State<DarkModeShell> createState() => _DarkModeShellState();
}

class _DarkModeShellState extends State<DarkModeShell> {
  final _key = GlobalKey(); // keeps every screen alive when the mode is switched

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: DarkMode.on,
      builder: (context, dark, _) {
        final kept = KeyedSubtree(key: _key, child: widget.child);
        return dark ? ColorFiltered(colorFilter: _appFilter, child: kept) : kept;
      },
    );
  }
}

/// Wrap photos, avatars and logos so they keep their real colours in dark mode.
class DarkSafe extends StatelessWidget {
  final Widget child;
  const DarkSafe({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: DarkMode.on,
      builder: (context, dark, c) => dark ? ColorFiltered(colorFilter: _photoFilter, child: c) : c!,
      child: child,
    );
  }
}

/// Moon / sun button for app bars.
class DarkModeButton extends StatelessWidget {
  const DarkModeButton({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: DarkMode.on,
      builder: (context, dark, _) => IconButton(
        tooltip: dark ? 'Light mode' : 'Dark mode',
        icon: Icon(dark ? Icons.light_mode_outlined : Icons.dark_mode_outlined),
        onPressed: DarkMode.toggle,
      ),
    );
  }
}
