// Picks the real Firebase code only for the Android / iPhone apps, so the website stays small and fast.
export 'native_push_stub.dart' if (dart.library.io) 'native_push_io.dart';
