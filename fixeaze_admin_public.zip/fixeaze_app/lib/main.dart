import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'config.dart';
import 'dark_mode.dart';
import 'screens/auth_gate.dart';
import 'services/native_push.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: AppConfig.supabaseUrl,
    anonKey: AppConfig.supabaseAnonKey,
  );
  await DarkMode.load();
  NativePush.start(); // phone notifications; does nothing on the website
  runApp(const FixeazeApp());
}

class FixeazeApp extends StatelessWidget {
  const FixeazeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Fixeaze',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      builder: (context, child) => DarkModeShell(child: child ?? const SizedBox()),
      home: const AuthGate(),
    );
  }
}
