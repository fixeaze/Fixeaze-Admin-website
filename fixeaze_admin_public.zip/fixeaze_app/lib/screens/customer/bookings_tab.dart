import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../config.dart';
import '../../widgets/common.dart';
import '../../widgets/booking_row.dart';
import '../invoice_screen.dart';
import '../../widgets/cancel_dialog.dart';
import '../../widgets/rating_dialog.dart';
import '../../widgets/fun_loader.dart';
import '../chat_screen.dart';
import '../help_screen.dart';
import '../job_watcher.dart';

class _BookingsData {
  final List<Map<String, dynamic>> bookings;
  final Map<String, Map<String, dynamic>> technicians; // by technician id
  final Set<String> reviewed; // booking ids that already have a review
  final Map<String, List<String>> notes; // admin notes by booking id
  _BookingsData(this.bookings, this.technicians, this.reviewed, [this.notes = const {}]);
}

class CustomerBookingsTab extends StatefulWidget {
  const CustomerBookingsTab({super.key});

  @override
  State<CustomerBookingsTab> createState() => _CustomerBookingsTabState();
}

class _CustomerBookingsTabState extends State<CustomerBookingsTab> {
  late Future<_BookingsData> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  void _refresh() => setState(() => _future = _load());

  Future<_BookingsData> _load() async {
    final uid = supabase.auth.currentUser!.id;

    final rows = await supabase
        .from('bookings')
        .select('*, services(name, base_price)')
        .eq('customer_id', uid)
        .order('created_at', ascending: false);
    final bookings = List<Map<String, dynamic>>.from(rows);

    final techIds = bookings
        .map((b) => b['technician_id'])
        .whereType<String>()
        .toSet()
        .toList();
    final techs = <String, Map<String, dynamic>>{};
    if (techIds.isNotEmpty) {
      final trows = await supabase
          .from('technician_profiles')
          .select('id, name, photo_url, rating')
          .inFilter('id', techIds);
      for (final r in trows) {
        techs[r['id'] as String] = Map<String, dynamic>.from(r);
      }
    }

    final revRows = await supabase.from('reviews').select('booking_id').eq('customer_id', uid);
    final reviewed = revRows.map((r) => r['booking_id'] as String).toSet();

    final notes = <String, List<String>>{};
    try {
      final nrows = await supabase
          .from('booking_notes')
          .select('booking_id, body')
          .eq('to_user', uid)
          .eq('to_role', 'customer')
          .order('created_at', ascending: false);
      for (final r in nrows) {
        notes.putIfAbsent('${r['booking_id']}', () => []).add('${r['body']}');
      }
    } catch (_) {
      // notes table not created yet: ignore
    }

    for (final e in techs.entries) {
      _lastTechNames[e.key] = '${e.value['name'] ?? ''}';
    }
    return _BookingsData(bookings, techs, reviewed, notes);
  }

  final Map<String, String> _lastTechNames = {};

  Future<void> _cancel(Map<String, dynamic> b) async {
    final r = await showCancelDialog(context, technician: false);
    if (r == null) return;
    try {
      await supabase.rpc('cancel_booking',
          params: {'p_booking': b['id'], 'p_reason': r.reason, 'p_note': r.note});
      if (mounted) snack(context, 'Booking cancelled');
    } on PostgrestException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    }
    if (mounted) _refresh();
  }

  Future<void> _review(Map<String, dynamic> b) async {
    final tname = (_lastTechNames[b['technician_id']] ?? 'your technician').toString();
    final r = await showRatingPopup(context,
        title: 'How was the service?',
        who: tname,
        tags: const ['On time', 'Polite', 'Skilled', 'Clean work', 'Late', 'Rude']);
    if (r == null) return;
    final rating = r.rating;
    final text = r.comment;
    try {
      await supabase.from('reviews').insert({
        'booking_id': b['id'],
        'customer_id': supabase.auth.currentUser!.id,
        'technician_id': b['technician_id'],
        'rating': rating,
        'comment': text.isEmpty ? null : text,
      });
      if (mounted) snack(context, 'Thanks for your review!');
    } on PostgrestException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    }
    if (mounted) _refresh();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<_BookingsData>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const FunLoader();
        }
        if (snap.hasError) {
          return ErrorState(error: snap.error!, onRetry: _refresh);
        }
        final data = snap.data!;
        if (data.bookings.isEmpty) {
          return const EmptyState(
            icon: Icons.receipt_long,
            text: 'No bookings yet.\nPick a service to book your first technician.',
          );
        }
        return RefreshIndicator(
          onRefresh: () async {
            _refresh();
            await _future;
          },
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: data.bookings.length + 1,
            itemBuilder: (context, i) {
              if (i == 0) return const BookingTableHeader();
              final b = data.bookings[i - 1];
              final status = (b['status'] ?? '').toString();
              final service = b['services'] as Map<String, dynamic>?;
              final tech = data.technicians[b['technician_id']];
              final photos = List<String>.from(b['photos'] ?? const []);
              final donePhotos = List<String>.from(b['completion_photos'] ?? const []);
              final techName = (tech?['name'] ?? 'Assigned').toString();
              final techRating = num.tryParse('${tech?['rating'] ?? 0}') ?? 0;
              final techLabel = techRating > 0
                  ? 'Technician: $techName  ★ $techRating'
                  : 'Technician: $techName';

              return BookingRow(
                title: (service?['name'] ?? 'Service').toString(),
                bookingNo: (b['booking_no'] ?? '').toString(),
                status: status,
                when: b['scheduled_at'],
                initiallyOpen: status == 'accepted' || status == 'in_progress',
                details: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      OrderProgress(b),
                      const SizedBox(height: 8),
                      if ((b['booking_no'] ?? '').toString().isNotEmpty)
                        Text('Booking ${b['booking_no']}',
                            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                      Text(bookingTypeLabel(b),
                          style: TextStyle(
                              color: Colors.teal.shade700,
                              fontSize: 12,
                              fontWeight: FontWeight.w600)),
                      const SizedBox(height: 4),
                      Row(children: [
                        const Icon(Icons.event, size: 16, color: Colors.black45),
                        const SizedBox(width: 6),
                        Expanded(child: Text(fmtDate(b['scheduled_at']))),
                      ]),
                      const SizedBox(height: 4),
                      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Icon(Icons.location_on, size: 16, color: Colors.black45),
                        const SizedBox(width: 6),
                        Expanded(child: Text((b['address'] ?? '').toString())),
                      ]),
                      if (tech != null || b['technician_id'] != null) ...[
                        const SizedBox(height: 4),
                        Row(children: [
                          const Icon(Icons.engineering, size: 16, color: Colors.black45),
                          const SizedBox(width: 6),
                          Expanded(child: Text(techLabel)),
                        ]),
                      ],
                      if (b['price'] != null) ...[
                        const SizedBox(height: 4),
                        Row(children: [
                          const Icon(Icons.payments, size: 16, color: Colors.black45),
                          const SizedBox(width: 6),
                          Text('Final price: ${money(b['price'])}'),
                        ]),
                      ] else if (service?['base_price'] != null) ...[
                        const SizedBox(height: 4),
                        Row(children: [
                          const Icon(Icons.payments, size: 16, color: Colors.black45),
                          const SizedBox(width: 6),
                          Text('Starting from ${money(service!['base_price'])}'),
                        ]),
                      ],
                      if ((b['notes'] ?? '').toString().isNotEmpty) ...[
                        const SizedBox(height: 8),
                        Text('"${b['notes']}"',
                            style: const TextStyle(
                                fontStyle: FontStyle.italic, color: Colors.black54)),
                      ],
                      for (final n in data.notes['${b['id']}'] ?? const <String>[])
                        Container(
                          width: double.infinity,
                          margin: const EdgeInsets.only(top: 8),
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                              color: Colors.amber.shade50,
                              borderRadius: BorderRadius.circular(10)),
                          child: Text('Note from Fixeaze: $n', style: const TextStyle(fontSize: 13)),
                        ),
                      if (photos.isNotEmpty) ...[
                        const SizedBox(height: 10),
                        PhotoStrip(urls: photos),
                      ],
                      if (donePhotos.isNotEmpty) ...[
                        const SizedBox(height: 10),
                        const Text('Work photos',
                            style: TextStyle(fontSize: 12, color: Colors.black54)),
                        const SizedBox(height: 4),
                        PhotoStrip(urls: donePhotos),
                      ],
                      if (b['technician_id'] != null &&
                          (status == 'accepted' ||
                              status == 'in_progress' ||
                              status == 'completed')) ...[
                        const SizedBox(height: 8),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: OutlinedButton.icon(
                            onPressed: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => ChatScreen(
                                  bookingId: b['id'] as String,
                                  title: 'Chat with $techName',
                                  canSend: status != 'completed',
                                ),
                              ),
                            ),
                            icon: const Icon(Icons.chat_bubble_outline, size: 18),
                            label: const Text('Chat with technician'),
                          ),
                        ),
                      ],
                      if ((status == 'accepted' || status == 'in_progress') &&
                          (b['job_stage'] ?? '').toString().isNotEmpty) ...[
                        const SizedBox(height: 8),
                        SizedBox(
                          width: double.infinity,
                          child: FilledButton.icon(
                            onPressed: () async {
                              await showCustomerJob(context, b['id'] as String);
                              if (mounted) _refresh();
                            },
                            icon: const Icon(Icons.notifications_active),
                            label: const Text('Job status / OTP'),
                          ),
                        ),
                      ],
                      if (status == 'pending' ||
                          (status == 'accepted' && (b['job_stage'] ?? '').toString().isEmpty)) ...[
                        const SizedBox(height: 8),
                        Align(
                          alignment: Alignment.centerRight,
                          child: TextButton.icon(
                            onPressed: () => _cancel(b),
                            icon: const Icon(Icons.close, size: 18),
                            label: const Text('Cancel booking'),
                            style: TextButton.styleFrom(foregroundColor: Colors.red.shade700),
                          ),
                        ),
                      ],
                      if (status == 'cancelled')
                        Align(
                          alignment: Alignment.centerRight,
                          child: OutlinedButton.icon(
                            onPressed: () => raiseTicketFor(context, b['id']),
                            icon: const Icon(Icons.support_agent, size: 18),
                            label: const Text('Raise a ticket'),
                          ),
                        ),
                      if (status == 'completed')
                        Align(
                          alignment: Alignment.centerRight,
                          child: TextButton.icon(
                            onPressed: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => InvoiceScreen.customer(bookingId: '${b['id']}'))),
                            icon: const Icon(Icons.receipt_long),
                            label: const Text('Invoice'),
                          ),
                        ),
                      if (status == 'completed' &&
                          b['technician_id'] != null &&
                          !data.reviewed.contains(b['id'])) ...[
                        const SizedBox(height: 8),
                        Align(
                          alignment: Alignment.centerRight,
                          child: FilledButton.icon(
                            onPressed: () => _review(b),
                            icon: const Icon(Icons.star),
                            label: const Text('Rate technician'),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }
}
