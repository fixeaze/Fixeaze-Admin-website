import 'package:flutter/material.dart';

/// Technician buttons, made easy to learn:
/// - GoButton: big, filled. The ONE next thing to do on a screen.
/// - SoftButton: white with a coloured border. Extra help, used less.
const kGoGreen = Color(0xFF1F4D3A);
const kCallGreen = Color(0xFF1F6B3A);
const kChatBlue = Color(0xFF1565C0);
const kMapOrange = Color(0xFFC2410C);
const kStopRed = Color(0xFFC62828);
const kStarBrown = Color(0xFF92400E);

class GoButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback? onPressed;
  final bool busy;
  const GoButton({super.key, required this.label, required this.icon, required this.onPressed, this.busy = false});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 66,
      child: FilledButton(
        onPressed: busy ? null : onPressed,
        style: FilledButton.styleFrom(
          backgroundColor: kGoGreen,
          foregroundColor: Colors.white,
          disabledBackgroundColor: kGoGreen.withAlpha(110),
          disabledForegroundColor: Colors.white70,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          padding: const EdgeInsets.symmetric(horizontal: 14),
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          busy
              ? const SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 3, color: Colors.white))
              : Icon(icon, size: 30),
          const SizedBox(width: 10),
          Flexible(
            child: Text(label,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700, height: 1.15)),
          ),
        ]),
      ),
    );
  }
}

class SoftButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback? onPressed;
  final bool compact;
  const SoftButton({
    super.key,
    required this.label,
    required this.icon,
    required this.color,
    required this.onPressed,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      onPressed: onPressed,
      style: OutlinedButton.styleFrom(
        backgroundColor: Colors.white,
        foregroundColor: color,
        minimumSize: Size(0, compact ? 46 : 54),
        side: BorderSide(color: onPressed == null ? color.withAlpha(90) : color, width: 2),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        padding: const EdgeInsets.symmetric(horizontal: 14),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, size: compact ? 20 : 22),
        const SizedBox(width: 7),
        Flexible(child: Text(label, style: TextStyle(fontSize: compact ? 15 : 16, fontWeight: FontWeight.w700))),
      ]),
    );
  }
}
