import 'dart:async';

import 'package:flutter/material.dart';
import '../../dark_mode.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../config.dart';
import '../../services/cloudinary_service.dart';
import '../../services/pincode_service.dart';
import '../../theme.dart';
import '../../widgets/common.dart';
import '../login_screen.dart';

/// Booking in steps: product > issue type > photos > address > technician.
class CatalogBookScreen extends StatefulWidget {
  final Map<String, dynamic> service;
  final Map<String, dynamic>? product; // chosen on the home page already
  final Map<String, dynamic>? item;
  /// Embedded in the service page (no Scaffold): the form sits under the choices.
  final bool embedded;
  final VoidCallback? onBooked;
  const CatalogBookScreen(
      {super.key, required this.service, this.product, this.item, this.embedded = false, this.onBooked});

  @override
  State<CatalogBookScreen> createState() => _CatalogBookScreenState();
}

class _CatalogBookScreenState extends State<CatalogBookScreen> {
  int _step = 0;
  bool get _one => widget.product != null && widget.item != null;
  int get _first => (widget.product != null && widget.item != null) ? 2 : 0;
  // steps: 0 product, 1 issue type, 2 photos, 3 address, 4 technician
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _products = [];
  List<Map<String, dynamic>> _items = [];
  Map<String, dynamic>? _product;
  Map<String, dynamic>? _item;

  final List<String> _photos = [];
  bool _uploading = false;
  final _notes = TextEditingController();
  final _address = TextEditingController();
  final _pincode = TextEditingController();
  DateTime? _date;
  TimeOfDay? _time;

  PinInfo? _pin;
  bool _checking = false;
  List<Map<String, dynamic>> _techs = [];
  String? _chosen; // null = any available technician
  bool _saving = false;

  static const _maxPhotos = 4;
  static const _titles = [
    'Choose a product',
    'What kind of work?',
    'Show us the issue',
    'Where and when?',
    'Choose a technician',
  ];

  @override
  void initState() {
    super.initState();
    if (_first == 2) {
      _product = widget.product;
      _item = widget.item;
      _step = 2;
      _loading = false;
    } else {
      _loadProducts();
    }
    _prefill();
  }

  @override
  void dispose() {
    _notes.dispose();
    _address.dispose();
    _pincode.dispose();
    super.dispose();
  }

  Future<void> _loadProducts() async {
    try {
      final rows = await supabase
          .from('catalog_products')
          .select()
          .eq('service_id', widget.service['id'])
          .eq('active', true)
          .order('sort')
          .order('name');
      if (!mounted) return;
      setState(() {
        _products = List<Map<String, dynamic>>.from(rows);
        _loading = false;
      });
    } catch (e) {
      if (mounted) setState(() {
        _error = '$e';
        _loading = false;
      });
    }
  }

  Future<void> _pickProduct(Map<String, dynamic> p) async {
    setState(() {
      _product = p;
      _item = null;
      _items = [];
      _loading = true;
      _step = 1;
    });
    try {
      final rows = await supabase
          .from('product_services')
          .select()
          .eq('product_id', p['id'])
          .eq('active', true)
          .order('sort')
          .order('name');
      if (!mounted) return;
      setState(() {
        _items = List<Map<String, dynamic>>.from(rows);
        _loading = false;
      });
    } catch (e) {
      if (mounted) setState(() {
        _error = '$e';
        _loading = false;
      });
    }
  }

  Future<void> _prefill() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;
    try {
      final p = await supabase.from('profiles').select('address, pincode').eq('id', user.id).maybeSingle();
      if (!mounted || p == null) return;
      final a = (p['address'] ?? '').toString();
      final pin = (p['pincode'] ?? '').toString();
      if (a.isNotEmpty && _address.text.isEmpty) _address.text = a;
      if (pin.isNotEmpty && _pincode.text.isEmpty) _pincode.text = pin;
      if (_one && PincodeService.isValid(_pincode.text.trim())) _loadTechs();
    } catch (_) {}
  }

  Future<void> _photo(bool camera) async {
    if (_photos.length >= _maxPhotos) return;
    setState(() => _uploading = true);
    try {
      final url = camera
          ? await CloudinaryService.captureAndUpload()
          : await CloudinaryService.pickAndUpload();
      if (url != null && mounted) setState(() => _photos.add(url));
    } catch (e) {
      if (mounted) snack(context, 'Could not add photo: $e', error: true);
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final d = await showDatePicker(
        context: context,
        initialDate: _date ?? now,
        firstDate: now,
        lastDate: now.add(const Duration(days: 90)));
    if (d != null) setState(() => _date = d);
  }

  Future<void> _pickTime() async {
    final t = await showTimePicker(
        context: context, initialTime: _time ?? const TimeOfDay(hour: 10, minute: 0));
    if (t != null) setState(() => _time = t);
  }

  Future<void> _toTechnicians() async {
    final pin = _pincode.text.trim();
    if (_address.text.trim().length < 5) {
      snack(context, 'Please enter your full address', error: true);
      return;
    }
    if (!PincodeService.isValid(pin)) {
      snack(context, 'Enter a valid 6-digit pincode', error: true);
      return;
    }
    if (_date == null || _time == null) {
      snack(context, 'Please choose a date and time', error: true);
      return;
    }
    final when = DateTime(_date!.year, _date!.month, _date!.day, _time!.hour, _time!.minute);
    if (when.isBefore(DateTime.now())) {
      snack(context, 'Please choose a time in the future', error: true);
      return;
    }
    setState(() => _checking = true);
    try {
      final info = await PincodeService.lookup(pin);
      if (info == null) {
        if (mounted) snack(context, 'We could not find this pincode', error: true);
        return;
      }
      final rows = await supabase.rpc('technicians_for_item', params: {
        'p_item': _item!['id'],
        'p_lat': info.lat,
        'p_lng': info.lng,
        'p_km': 10,
      });
      if (!mounted) return;
      setState(() {
        _pin = info;
        _techs = List<Map<String, dynamic>>.from(rows as List);
        _chosen = null;
        _step = 4;
      });
    } catch (e) {
      if (mounted) snack(context, 'Could not check technicians: $e', error: true);
    } finally {
      if (mounted) setState(() => _checking = false);
    }
  }

  /// One-page mode: loads technicians as soon as a valid pincode is typed.
  Future<void> _loadTechs() async {
    final pin = _pincode.text.trim();
    if (!PincodeService.isValid(pin) || _item == null) return;
    setState(() => _checking = true);
    try {
      final info = await PincodeService.lookup(pin);
      if (!mounted || pin != _pincode.text.trim()) return;
      if (info == null) {
        setState(() { _pin = null; _techs = []; });
        snack(context, 'We could not find this pincode', error: true);
        return;
      }
      final rows = await supabase.rpc('technicians_for_item', params: {
        'p_item': _item!['id'],
        'p_lat': info.lat,
        'p_lng': info.lng,
        'p_km': 10,
      });
      if (!mounted) return;
      setState(() {
        _pin = info;
        _techs = List<Map<String, dynamic>>.from(rows as List);
        if (_chosen != null && !_techs.any((t) => '${t['id']}' == _chosen)) _chosen = null;
      });
    } catch (e) {
      if (mounted) snack(context, 'Could not check technicians: $e', error: true);
    } finally {
      if (mounted) setState(() => _checking = false);
    }
  }

  num? _minPrice() => _techs.isEmpty ? null : _techs.map((t) => t['price'] as num).reduce((a, b) => a < b ? a : b);
  num? _maxPrice() => _techs.isEmpty ? null : _techs.map((t) => t['price'] as num).reduce((a, b) => a > b ? a : b);

  Future<void> _book() async {
    if (supabase.auth.currentUser == null) {
      snack(context, 'Please log in or sign up to place your booking');
      await Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
      if (supabase.auth.currentUser == null) return;
    }
    if (_address.text.trim().length < 5) {
      snack(context, 'Please enter your full address', error: true);
      return;
    }
    if (_pin == null) {
      snack(context, 'Enter a valid 6-digit pincode', error: true);
      return;
    }
    if (_date == null || _time == null) {
      snack(context, 'Please choose a date and time', error: true);
      return;
    }
    final when = DateTime(_date!.year, _date!.month, _date!.day, _time!.hour, _time!.minute);
    if (when.isBefore(DateTime.now())) {
      snack(context, 'Please choose a time in the future', error: true);
      return;
    }
    setState(() => _saving = true);
    try {
      await supabase.from('bookings').insert({
        'customer_id': supabase.auth.currentUser!.id,
        'service_id': widget.service['id'],
        'product_id': _product!['id'],
        'item_id': _item!['id'],
        'booking_type': 'hourly',
        'address': _address.text.trim(),
        'pincode': _pin!.pincode,
        'lat': _pin!.lat,
        'lng': _pin!.lng,
        'scheduled_at': when.toUtc().toIso8601String(),
        'notes': _notes.text.trim(),
        'photos': _photos,
        'status': 'pending',
        if (_chosen != null) 'preferred_technician_id': _chosen,
      });
      if (!mounted) return;
      snack(context, _chosen != null
          ? 'Booking sent! Your technician has 30 minutes to accept.'
          : 'Booking sent to all available technicians near you.');
      if (widget.embedded) {
        widget.onBooked?.call();
      } else {
        Navigator.pop(context, true);
      }
    } on PostgrestException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    } catch (e) {
      if (mounted) snack(context, 'Could not create booking: $e', error: true);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  bool _back() {
    if (_step <= _first) return true;
    setState(() => _step--);
    return false;
  }

  // ---------- UI ----------
  Widget _img(String? url, IconData icon, {double size = 56}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Container(
        width: size,
        height: size,
        color: kTeal.withOpacity(0.1),
        child: url == null || url.isEmpty
            ? Icon(icon, color: kTeal)
            : DarkSafe(child: Image.network(CloudinaryService.optimized(url, width: 200), fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Icon(icon, color: kTeal))),
      ),
    );
  }

  Widget _choiceList(List<Map<String, dynamic>> rows, IconData icon, void Function(Map<String, dynamic>) onTap, String empty) {
    if (rows.isEmpty) return EmptyState(icon: icon, text: empty);
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: rows.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (_, i) {
        final r = rows[i];
        var d = (r['description'] ?? '').toString();
        final lo = r['price_min'], hi = r['price_max'];
        if (lo != null && hi != null) {
          d = d.isEmpty ? 'Typically ${money(lo)} - ${money(hi)}' : '$d\nTypically ${money(lo)} - ${money(hi)}';
        }
        return Card(
          margin: EdgeInsets.zero,
          child: ListTile(
            contentPadding: const EdgeInsets.all(10),
            leading: _img(r['image_url'] as String?, icon),
            title: Text('${r['name']}', style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: d.isEmpty ? null : Text(d, maxLines: 2, overflow: TextOverflow.ellipsis),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => onTap(r),
          ),
        );
      },
    );
  }

  Widget _photoStep() {
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('${_product!['name']}  >  ${_item!['name']}',
          style: const TextStyle(fontWeight: FontWeight.w600, color: kTeal)),
      const SizedBox(height: 12),
      const Text('Add photos of the issue (optional, up to 4)',
          style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      Row(children: [
        Expanded(
          child: OutlinedButton.icon(
              onPressed: _uploading || _photos.length >= _maxPhotos ? null : () => _photo(true),
              icon: const Icon(Icons.photo_camera),
              label: const Text('Camera')),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: OutlinedButton.icon(
              onPressed: _uploading || _photos.length >= _maxPhotos ? null : () => _photo(false),
              icon: const Icon(Icons.photo_library),
              label: const Text('Gallery')),
        ),
      ]),
      if (_uploading) const Padding(padding: EdgeInsets.all(12), child: LinearProgressIndicator()),
      const SizedBox(height: 12),
      Wrap(spacing: 8, runSpacing: 8, children: [
        for (final u in _photos)
          Stack(children: [
            _img(u, Icons.image, size: 88),
            Positioned(
              right: 0,
              top: 0,
              child: InkWell(
                onTap: () => setState(() => _photos.remove(u)),
                child: const CircleAvatar(radius: 11, backgroundColor: Colors.black54, child: Icon(Icons.close, size: 14, color: Colors.white)),
              ),
            ),
          ]),
      ]),
      const SizedBox(height: 16),
      TextField(
        controller: _notes,
        maxLines: 3,
        decoration: const InputDecoration(labelText: 'Tell us briefly about the issue', border: OutlineInputBorder()),
      ),
      const SizedBox(height: 16),
      FilledButton(onPressed: () => setState(() => _step = 3), child: const Text('Continue')),
    ]);
  }

  Widget _addressStep() {
    return ListView(padding: const EdgeInsets.all(16), children: [
      TextField(
        controller: _address,
        maxLines: 3,
        decoration: const InputDecoration(labelText: 'Full address', border: OutlineInputBorder()),
      ),
      const SizedBox(height: 12),
      TextField(
        controller: _pincode,
        keyboardType: TextInputType.number,
        maxLength: 6,
        decoration: const InputDecoration(labelText: 'Pincode', border: OutlineInputBorder(), counterText: ''),
      ),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(
          child: OutlinedButton.icon(
              onPressed: _pickDate,
              icon: const Icon(Icons.event),
              label: Text(_date == null ? 'Date' : DateFormat('d MMM yyyy').format(_date!))),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: OutlinedButton.icon(
              onPressed: _pickTime,
              icon: const Icon(Icons.schedule),
              label: Text(_time == null ? 'Time' : _time!.format(context))),
        ),
      ]),
      const SizedBox(height: 20),
      FilledButton(
        onPressed: _checking ? null : _toTechnicians,
        child: Text(_checking ? 'Checking...' : 'See available technicians'),
      ),
    ]);
  }

  List<Widget> _techItems() {
    final lo = _minPrice(), hi = _maxPrice();
    String range() => lo == null ? '' : (lo == hi ? money(lo) : '${money(lo)} - ${money(hi)}');
    return [
          if (_techs.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Text('No technician is available for this service in your area yet. Please try another pincode or come back later.'),
              ),
            )
          else ...[
            Card(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                  side: BorderSide(color: _chosen == null ? kTeal : Colors.transparent, width: 2)),
              child: ListTile(
                onTap: () => setState(() => _chosen = null),
                leading: const CircleAvatar(backgroundColor: kTeal, child: Icon(Icons.groups, color: Colors.white)),
                title: const Text('Any available technician', style: TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('${_techs.length} available. Fastest to accept.\nYou pay the charge of the technician who accepts.'),
                isThreeLine: true,
                trailing: Text(range(), style: const TextStyle(fontWeight: FontWeight.bold, color: kTeal)),
              ),
            ),
            const SizedBox(height: 8),
            for (final t in _techs)
              Card(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                    side: BorderSide(color: _chosen == t['id'] ? kTeal : Colors.transparent, width: 2)),
                child: ListTile(
                  onTap: () => setState(() => _chosen = '${t['id']}'),
                  leading: DarkSafe(child: CircleAvatar(
                    backgroundImage: (t['avatar_url'] ?? '').toString().isEmpty ? null : NetworkImage('${t['avatar_url']}'),
                    child: (t['avatar_url'] ?? '').toString().isEmpty ? const Icon(Icons.person) : null,
                  )),
                  title: Text('${t['name'] ?? 'Technician'}', style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text(
                      '${(num.tryParse('${t['rating'] ?? 0}') ?? 0).toStringAsFixed(1)} rating  |  ${t['jobs_done'] ?? 0} jobs  |  ${t['experience'] ?? 0} yrs  |  ${(num.tryParse('${t['km'] ?? 0}') ?? 0).toStringAsFixed(1)} km'),
                  trailing: Text(money(t['price']), style: const TextStyle(fontWeight: FontWeight.bold, color: kTeal)),
                ),
              ),
            const SizedBox(height: 8),
            Text(
              _chosen == null
                  ? 'Your booking goes to every available technician near you. The first to accept gets the job.'
                  : 'Your chosen technician has 30 minutes to accept. After that it opens to other technicians.',
              style: const TextStyle(color: Colors.black54, fontSize: 13),
            ),
            const SizedBox(height: 4),
            const Text('Spare parts, if needed, are added on site and shown before you pay.',
                style: TextStyle(color: Colors.black54, fontSize: 13)),
          ],
    ];
  }

  Widget _techStep() {
    return Column(children: [
      Expanded(
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Text('${_product!['name']}  >  ${_item!['name']}',
              style: const TextStyle(fontWeight: FontWeight.w600, color: kTeal)),
          const SizedBox(height: 4),
          Text('Pincode ${_pin!.pincode}', style: const TextStyle(color: Colors.black54)),
          const SizedBox(height: 12),
          ..._techItems(),
        ]),
      ),
      if (_techs.isNotEmpty)
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: _saving ? null : _book,
                child: Text(_saving ? 'Booking...' : 'Confirm booking'),
              ),
            ),
          ),
        ),
    ]);
  }

  Widget _sec(String n, String t) => Padding(
        padding: const EdgeInsets.fromLTRB(0, 22, 0, 10),
        child: Row(children: [
          CircleAvatar(radius: 13, backgroundColor: kTeal,
              child: Text(n, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w800))),
          const SizedBox(width: 10),
          Expanded(child: Text(t, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17))),
        ]),
      );

  int _n(int i) => widget.embedded ? i + 2 : i;

  List<Widget> _formChildren(bool header) => [
          if (header) Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: kTeal.withOpacity(0.08), borderRadius: BorderRadius.circular(16)),
            child: Row(children: [
              const Icon(Icons.build_circle, color: kTeal),
              const SizedBox(width: 10),
              Expanded(
                child: Text('${_product!['name']}  >  ${_item!['name']}',
                    style: const TextStyle(fontWeight: FontWeight.w800)),
              ),
            ]),
          ),
          _sec('${_n(1)}', 'Show us the issue'),
          Row(children: [
            Expanded(
              child: OutlinedButton.icon(
                  onPressed: _uploading || _photos.length >= _maxPhotos ? null : () => _photo(true),
                  icon: const Icon(Icons.photo_camera),
                  label: const Text('Camera')),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton.icon(
                  onPressed: _uploading || _photos.length >= _maxPhotos ? null : () => _photo(false),
                  icon: const Icon(Icons.photo_library),
                  label: const Text('Gallery')),
            ),
          ]),
          if (_uploading) const Padding(padding: EdgeInsets.all(12), child: LinearProgressIndicator()),
          if (_photos.isNotEmpty) ...[
            const SizedBox(height: 10),
            Wrap(spacing: 8, runSpacing: 8, children: [
              for (final u in _photos)
                Stack(children: [
                  _img(u, Icons.image, size: 88),
                  Positioned(
                    right: 0,
                    top: 0,
                    child: InkWell(
                      onTap: () => setState(() => _photos.remove(u)),
                      child: const CircleAvatar(radius: 11, backgroundColor: Colors.black54, child: Icon(Icons.close, size: 14, color: Colors.white)),
                    ),
                  ),
                ]),
            ]),
          ],
          const SizedBox(height: 12),
          TextField(
            controller: _notes,
            maxLines: 3,
            decoration: const InputDecoration(labelText: 'Tell us briefly about the issue (optional)'),
          ),
          _sec('${_n(2)}', 'Where and when?'),
          TextField(
            controller: _address,
            maxLines: 2,
            decoration: const InputDecoration(labelText: 'Full address'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _pincode,
            keyboardType: TextInputType.number,
            maxLength: 6,
            onChanged: (v) {
              if (v.trim().length == 6) {
                _loadTechs();
              } else if (_pin != null) {
                setState(() { _pin = null; _techs = []; _chosen = null; });
              }
            },
            decoration: const InputDecoration(labelText: 'Pincode', counterText: ''),
          ),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(
              child: OutlinedButton.icon(
                  onPressed: _pickDate,
                  icon: const Icon(Icons.event),
                  label: Text(_date == null ? 'Date' : DateFormat('d MMM yyyy').format(_date!))),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton.icon(
                  onPressed: _pickTime,
                  icon: const Icon(Icons.schedule),
                  label: Text(_time == null ? 'Time' : _time!.format(context))),
            ),
          ]),
          _sec('${_n(3)}', 'Choose a technician'),
          if (_checking)
            const Padding(padding: EdgeInsets.all(12), child: LinearProgressIndicator())
          else if (_pin == null)
            const Text('Enter your 6-digit pincode above to see technicians near you.',
                style: TextStyle(color: Colors.black54))
          else
            ..._techItems(),
  ];

  /// Everything from photos to confirm on a single scrolling page.
  Widget _onePage() {
    return Column(children: [
      Expanded(
        child: ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 16), children: _formChildren(true)),
      ),
      SafeArea(
        top: false,
        child: Container(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
          decoration: const BoxDecoration(color: kCream, border: Border(top: BorderSide(color: kLine))),
          child: SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: (_saving || _techs.isEmpty) ? null : _book,
              child: Text(_saving ? 'Booking...' : 'Confirm booking'),
            ),
          ),
        ),
      ),
    ]);
  }

  /// The same form, placed inside another page's scroll view.
  Widget _embeddedForm() {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      ..._formChildren(false),
      const SizedBox(height: 18),
      FilledButton(
        onPressed: (_saving || _techs.isEmpty) ? null : _book,
        child: Text(_saving ? 'Booking...' : 'Confirm booking'),
      ),
      const SizedBox(height: 28),
    ]);
  }

  Widget _body() {
    if (_error != null) return ErrorState(error: _error!, onRetry: () {
      setState(() { _error = null; _loading = true; });
      _step == 0 ? _loadProducts() : _pickProduct(_product!);
    });
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_one) return _onePage();
    switch (_step) {
      case 0:
        return _choiceList(_products, Icons.devices_other, _pickProduct, 'No products added for this service yet.');
      case 1:
        return _choiceList(_items, Icons.build, (r) => setState(() { _item = r; _step = 2; }), 'No work types added for this product yet.');
      case 2:
        return _photoStep();
      case 3:
        return _addressStep();
      default:
        return _techStep();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.embedded) return _one ? _embeddedForm() : const SizedBox.shrink();
    return WillPopScope(
      onWillPop: () async => _back(),
      child: Scaffold(
        appBar: AppBar(
          title: Text(_one ? 'Book ${widget.service['name']}' : '${widget.service['name']}: ${_titles[_step]}'),
          leading: BackButton(onPressed: () {
            if (_back()) Navigator.pop(context);
          }),
        ),
        body: _body(),
      ),
    );
  }
}
