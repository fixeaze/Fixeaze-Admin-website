import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../app_state.dart';
import '../config.dart';
import '../services/pincode_service.dart';
import '../widgets/common.dart';

/// Shown once after "Continue with Google": we still need a mobile number and pincode.
class CompleteProfileScreen extends StatefulWidget {
  final Map<String, dynamic> profile;
  final VoidCallback onDone;
  const CompleteProfileScreen({super.key, required this.profile, required this.onDone});

  @override
  State<CompleteProfileScreen> createState() => _CompleteProfileScreenState();
}

class _CompleteProfileScreenState extends State<CompleteProfileScreen> {
  final _form = GlobalKey<FormState>();
  late final _name = TextEditingController(text: '${widget.profile['name'] ?? ''}');
  final _phone = TextEditingController();
  final _pin = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _pin.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      final pin = await PincodeService.lookup(_pin.text);
      if (pin == null) {
        if (mounted) snack(context, 'We could not find this pincode. Check it and try again.', error: true);
        return;
      }
      await supabase.rpc('complete_profile', params: {
        'p_name': _name.text.trim(),
        'p_phone': _phone.text.trim(),
        'p_pincode': pin.pincode,
        'p_lat': pin.lat,
        'p_lng': pin.lng,
      });
      widget.onDone();
    } on PostgrestException catch (e) {
      if (mounted) snack(context, e.message, error: true);
    } catch (e) {
      if (mounted) snack(context, 'Something went wrong: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const AppBarTitle(), actions: [
        TextButton(onPressed: signOutAll, child: const Text('Sign out')),
      ]),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Constrained(
            maxWidth: 420,
            child: Form(
              key: _form,
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                const Text('One last step', textAlign: TextAlign.center, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                const Text('Add your mobile number and pincode so technicians can reach you.',
                    textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
                const SizedBox(height: 20),
                TextFormField(
                  controller: _name,
                  decoration: const InputDecoration(labelText: 'Full name', prefixIcon: Icon(Icons.badge)),
                  validator: (v) => (v == null || v.trim().length < 2) ? 'Enter your name' : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _phone,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(labelText: 'Mobile number', prefixIcon: Icon(Icons.phone)),
                  validator: (v) => (v == null || v.trim().length < 10) ? 'Enter a valid mobile number' : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _pin,
                  keyboardType: TextInputType.number,
                  maxLength: 6,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  decoration: const InputDecoration(labelText: 'Pincode', prefixIcon: Icon(Icons.pin_drop), counterText: ''),
                  validator: (v) => (v == null || !PincodeService.isValid(v)) ? 'Enter a valid 6-digit pincode' : null,
                ),
                const SizedBox(height: 20),
                FilledButton(
                  onPressed: _busy ? null : _save,
                  child: _busy
                      ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Text('Continue'),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
